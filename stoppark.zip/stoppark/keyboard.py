import sys
from subprocess import Popen
from PyQt4 import uic
from PyQt4.QtGui import QLineEdit, QDialog
from db import Ticket
from i18n import language
import coding
_ = language.ugettext


class Keyboard(object):
    keyboard = None

    @classmethod
    def show(cls, layout=None):
        if sys.platform == 'win32':
            return
        if cls.keyboard is not None:
            if cls.keyboard.poll() is None:
                cls.keyboard.terminate()
                #return
        cls.keyboard = Popen(['/usr/local/bin/florence'])




class TouchLineEdit(QLineEdit):
    def __init__(self, *args):
        QLineEdit.__init__(self, *args)

    #noinspection PyPep8Naming
    def focusInEvent(self, e):
        Keyboard.show()


class TicketInput(QDialog):
    def __init__(self, parent=None):
        QDialog.__init__(self, parent)

        self.ui = uic.loadUiType('data-input.ui')[0]()
        self.ui.setupUi(self)
        self.localize()

        self.ui.ok.clicked.connect(self.ok)
        self.ui.cancel.clicked.connect(self.cancel)
        self.ui.keyboard.clicked.connect(self.show_keyboard)
        self.ui.data.textChanged.connect(self.bar_changed)

        self.ui.data.setFocus(True)
        self.show_keyboard()


    def localize(self):
        self.setWindowTitle(_('Manual barcode input'))
        self.ui.data.setPlaceholderText(_('Input barcode'))
        self.ui.ok.setText(_('OK'))
        self.ui.cancel.setText(_('Cancel'))

    def show_keyboard(self):
        Keyboard.show()
        self.ui.data.setFocus(True)

    @property
    def bar(self):
        return str(self.ui.data.text())

    def bar_changed(self, bar):
        bar = coding.decrypt(str(bar))
	print ("keyboard in ", bar)
        try:
            assert(len(bar) == Ticket.BAR_LENGTH)
            Ticket.parse_bar(bar)
            self.ui.ok.setEnabled(True)
            self.ui.data.setStyleSheet('background-color: #bbffbb')
        except (ValueError, AssertionError):
            self.ui.ok.setEnabled(False)
            self.ui.data.setStyleSheet('background-color: #ffbbbb')

    def ok(self):
        self.accept()

    def cancel(self):
        self.reject()


class UnitsInput(QDialog):
    def __init__(self, Title, PlaceholderText, parent=None):
        QDialog.__init__(self, parent)

        self.ui = uic.loadUiType('data-input.ui')[0]()
        self.ui.setupUi(self)


        self.ui.ok.clicked.connect(self.ok)
        self.ui.cancel.clicked.connect(self.cancel)
        self.ui.keyboard.clicked.connect(self.show_keyboard)
        self.ui.data.textChanged.connect(self.units_changed)

        self.Title = Title
        self.PlaceholderText = PlaceholderText

        self.localize()

        self.ui.data.setFocus(True)
        self.show_keyboard()

    def localize(self):
        self.setWindowTitle(self.Title)
        self.ui.data.setPlaceholderText(self.PlaceholderText)
        self.ui.ok.setText(_('OK'))
        self.ui.cancel.setText(_('Cancel'))

    def show_keyboard(self):
        Keyboard.show()
        self.ui.data.setFocus(True)

    @property
    def units(self):
        return str(self.ui.data.text())

    def units_changed(self):
        try:
            float(str(self.ui.data.text()))
            self.ui.ok.setEnabled(True)
            self.ui.data.setStyleSheet('background-color: #bbffbb')
        except ValueError:
            self.ui.ok.setEnabled(False)
            self.ui.data.setStyleSheet('background-color: #ffbbbb')

    def ok(self):
        self.accept()

    def cancel(self):
        self.reject()


