# -*- coding: utf-8 -*-
from datetime import datetime
from config import DATETIME_FORMAT_USER, LOCAL_DATETIME_FORMAT
from i18n import language

_ = language.ugettext


class Report(object):
    def __init__(self, db):
        self.db = db
        self.begin = '?'
        session = self.db.local.session()
        if session is not None:
            sn, operator, access, self.begin, end = session
            try:
                self.begin = datetime.strptime(self.begin, LOCAL_DATETIME_FORMAT).strftime(DATETIME_FORMAT_USER)
            except ValueError:
                pass

        self.header = self.db.get_check_header()
        self.total_places = self.db.get_total_places()
        self.free_places = self.db.get_free_places()

        self.sum = db.local.query('select sum(summa)/100 from payment')[0][0]
        self.sumCards = db.local.query('select sum(summa)/100 from payment where payment="Card payment"')[0][0]
        self.sumTickets = db.local.query('select sum(summa)/100 from payment where payment="Talon payment"')[0][0]

        if self.sum is None:
            self.sum = 0
        if self.sumCards is None:
            self.sumCards = 0
        if self.sumTickets is None:
            self.sumTickets = 0

        moved_in_query = ('select count(*) from events '
                          'where Direction="%s" and EventName="%s"' %
                          (_('inside').encode('utf8', errors='replace'),
                           _('pass').encode('utf8', errors='replace')))
        self.moved_in = db.local.query(moved_in_query)[0][0]

        self.moved_out = db.local.query('select count(*) from events '
                                        'where Direction="%s" and EventName="%s"' %
                                        (_('outside').encode('utf8', errors='replace'),
                                         _('pass').encode('utf8', errors='replace')))[0][0]

        self.card_moved_out = db.local.query('select count(*) from events '
                                             'where Direction="%s" and EventName="%s"'
                                             'and Card is not null' %
                                             (_('outside').encode('utf8', errors='replace'),
                                              _('pass').encode('utf8', errors='replace')))[0][0]

        self.card_moved_in = db.local.query('select count(*) from events '
                                            'where Direction="%s" and EventName="%s"'
                                            'and Card is not null' %
                                            (_('inside').encode('utf8', errors='replace'),
                                            _('pass').encode('utf8', errors='replace')))[0][0]

        self.talonPaymentCount = db.local.query('select count(*) from payment where payment="Talon payment"')[0][0]
        self.moved_in -= self.card_moved_in
        self.moved_out -= self.card_moved_out  # information about cards moving out is doubled in database
        self.ticket_moved_out = self.moved_out - self.card_moved_out
        self.ticket_moved_in  = self.moved_in - self.card_moved_in

    def __unicode__(self):
        return _('Cash: ${self.sum}\n'
                 'Moved inside: %{self.moved_in}\n'
                 'Moved outside: %{self.moved_out}\n'
                 'Moved outside using card: %{self.card_moved_out}\n').format(self=self)

    def check(self, cashier=None):
        """
        >>> from db import DB
        >>> report = Report(DB()) #doctest:+ELLIPSIS
        0...
        0...
        >>> report.check() #doctest:+ELLIPSIS
        u...
        """
        if cashier is not None:
            footer = _('Session completed by: %s\n<c>***SESSION COMPLETED***</c>') % (cashier,)
        else:
            footer = _('<c>TEMPORARY REPORT</c>')

        return (self.header +
                _('<c><s>Report on period</s></c>\n'
                  '\n'
                  'from {self.begin}\n'
                  'to {now}\n'
                  'all places: {self.total_places}\n'
                  '      free: {self.free_places}\n'
                  '   tickets: {self.ticket_moved_in}\n'
                  '     cards: {self.card_moved_in}\n'
                  '        in: {self.moved_in}\n'
                  '   tickets: {self.ticket_moved_out}\n'
                  '     cards: {self.card_moved_out}\n'
                  '       out: {self.moved_out}\n'
                  '\n'
                  ' Cards sum: {self.sumCards}\n'
                  'Ticket sum: {self.sumTickets}\n'
                  '       Sum: {self.sum}\n'
                  '\n').format(self=self, now=datetime.now().strftime(DATETIME_FORMAT_USER)) +
                footer + u'\n<hr />')


if __name__ == '__main__':
    import doctest

    doctest.testmod()



