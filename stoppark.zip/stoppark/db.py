﻿# coding=utf-8
from PyQt4.QtCore import pyqtSignal, QObject
from gevent import socket
from datetime import datetime
from time import time as measurement
from ticket import Ticket
from card import Card
from tariff import Tariff
from config import db_filename, DATETIME_FORMAT
import sqlite3
from collections import namedtuple
from i18n import language
import time
import os
import cam
#import logging
_ = language.ugettext


TerminalData = namedtuple('TerminalData', ['title', 'notify', 'option'])

def measure(f):
    def wrapper(*args, **kw):
        begin = measurement()
        ret = f(*args, **kw)
        elapsed = measurement() - begin
        #print 'db measure: ', elapsed, args, ret
        print 'db_measure_log'
        return ret

    return wrapper


FREE_PLACES_UPDATE_INTERVAL = 25


class LocalDB(object):
    script = """
    PRAGMA journal_mode=WAL;

    create table if not exists terminal (
        id integer primary key,
        title text,
        display integer default 1,
        notify integer default 1,
        option text default ''
    );

    create view if not exists terminal_view as select * from terminal;

    create trigger if not exists terminal_view_insert_existing
    instead of insert on terminal_view
    when exists (select * from terminal where id = new.id)
    begin
        update terminal set title=new.title where id=new.id;
    end;

    create trigger if not exists terminal_view_insert_new
    instead of insert on terminal_view
    when not exists (select * from terminal where id = new.id)
    begin
        insert into terminal (id, title) values(new.id, new.title);
    end;

    create table if not exists tariffs (
        id integer primary key,
        name text,
        type integer,
        interval integer,
        cost integer,
        zerotime text,
        maxperday text,
        note text
    );
    create table if not exists payment (
        id integer primary key,
        payment text,
        type integer,
        kassa integer,
        operator text,
        DTime text,
        TalonID text,
        Status integer,
        TarifType integer,
        Tarif integer,
        TarifKol integer,
        DTIn text,
        DTOut text,
        Summa integer
    );
    create table if not exists events (
        event text not null default "Event",
        id integer primary key,
        EventName text,
        DateTime text,
        Terminal integer,
        Direction text,
        Reason text,
        FreePlaces integer,
        Card text,
        GosNom text
    );
    create table if not exists gstatus (
        id integer primary key,
        placefree integer
    );
    replace into gstatus(id, placefree) values(0, 100);

    create table if not exists config (
        Config text,
        id integer primary key,
        PlaceNum integer,
        FreeTime integer,
        PayTime text,
        TarifName1 text,
        TarifName2 text,
        TarifName3 text,
        TarifName4 text,
        UserStr1 text,
        UserStr2 text,
        UserStr3 text,
        UserStr4 text,
        UserStr5 text,
        UserStr6 text,
        UserStr7 text,
        UserStr8 text,
        PlaceFree integer
    );

    create table if not exists session (
        id integer primary key default (null),
        sn text,
        operator text,
        access text,
        begin text default (datetime(current_timestamp, 'localtime')),
        end text default (null)
    );

    create table if not exists opt (
        id integer primary key default (null),
        key text,
        value text
    );
    """

    INIT_CONFIG_QUERY = ('insert into config(id,PlaceNum,FreeTime,'
                         'UserStr1,UserStr2,UserStr3,UserStr4,'
                         'UserStr5,UserStr6,UserStr7,UserStr8,PlaceFree) '
                         'values(null,100,15,?,?,?,?,?,?,?,?,0)')

    def __init__(self, filename=None, initialize=False):
        sqlite3.enable_shared_cache(True)
        print 'LocalDB_init_sqlite3.enable_log'
        if filename is None:
            filename = db_filename

        self.filename = filename
        #self.conn = sqlite3.connect(self.filename, isolation_level='DEFERRED')
        self.conn = sqlite3.connect(self.filename, timeout=1, isolation_level=None)  # autocommit mode
        self.conn.row_factory = sqlite3.Row
        self.conn.text_factory = str

        self.free_places_update_time = None

        if initialize:
            self.initialize()

    def initialize(self):
        with self.conn as c:
            c.executescript(LocalDB.script)

        print 'LocalDB_initialize_log'
        if self.query('select count(*) from config')[0][0] == 0:
            with self.conn as c:
                default_strings = _('CARD-SYSTEMS\n'
                                    'Kyiv\n'
                                    'Peremohy ave, 123\n'
                                    '(+380 44) 284 0888\n'
                                    'EXAMPLE\n'
                                    'CAUTION! Do not crumple tickets!\n'
                                    'Ticket loss will be penalized\n'
                                    'EXAMPLE').split(u'\n')
                c.execute(LocalDB.INIT_CONFIG_QUERY, default_strings)

        if self.option('db.ip') is None:
            self.set_option('db.ip', '127.0.0.1')

    def set_option(self, key, value):
        print 'LocalDB_set_option', key, value
        with self.conn as c:
            cursor = c.cursor()
            try:
                cursor.execute('update opt set value=? where key=?', (value, key))
                if cursor.rowcount == 0:
                    c.execute('insert into opt(key,value) values(?,?)', (key, value))
            except self.conn.OperationalError as e:
                print 'Error localDB set_option ' + str(e)

    def option(self, key):
        print 'LocalDB_option_log'
        with self.conn as c:
            for row in c.execute('select value from opt where key=?', (key,)):
                return row[0]

    def all_options(self):
        print 'LocalDB_all_options_log'
        with self.conn as c:
            return c.execute('select key,value from opt')

    def get_db_addr(self):
        print 'LocalDB_get_db_addr_log'
        return self.option('db.ip'), 101

    def session_begin(self, card):
        print 'LocalDB_session_begin_log'
        with self.conn as c:
            c.execute('insert into session(sn, operator, access) values(?,?,?)', (card.sn, card.fio, card.access))

    def session(self):
        print 'LocalDB_session_log'
        with self.conn as c:
            for row in c.execute('select sn,operator,access,begin,end from session '
                                 'where id=(select max(id) from session)'):
                return row

    def session_end(self):
        print 'LocalDB_session_end_log'
        with self.conn as c:
            c.execute('delete from payment')
            c.execute('delete from events')
            c.execute('update session set end=datetime(current_timestamp, "localtime")'
                      'where id=(select max(id) from session)')

    def connection(self):
        print 'LocalDB_connectio_log'
        return self.conn

    def query(self, q, *args):
        print 'LocalDB_query1_log'
        cursor = self.conn.execute(q, *args)
        for row in cursor:
            print row
        time.sleep(.150)
        print 'LocalDB_query2_log'
        cursor = self.conn.execute(q, *args)
        return [row for row in cursor]

    def update_free_places(self, free_places):
        with self.conn as c:
            c.execute('update Config set PlaceFree=?', (free_places,))
            self.free_places_update_time = measurement()
            print 'LocalDB_update_free_places_log'

    def get_free_places(self):
        print 'LocalDB_get_free_places_log'
        print self.free_places_update_time
        if self.free_places_update_time is None:
            return 0, False
        return (self.query('select PlaceFree from Config')[0][0],
                measurement() - self.free_places_update_time < FREE_PLACES_UPDATE_INTERVAL)
       

    def update_terminals(self, terminals):
        print 'LocalDB_update_terminals_log'
        with self.conn as c:
            c.executemany('insert into terminal_view(id, title) values(?,?)', terminals)
            c.execute('delete from terminal where id not in (%s)' % (','.join(('?',) * len(terminals)),),
                      [t[0] for t in terminals])
            print 'LocalDB_update_terminals1_log'
            

    def get_terminals(self):
        print 'LocalDB_get_terminals_log'
        return self.query('select id,title,notify,option from terminal where display = 1')
        

    def update_tariffs(self, tariffs):
        print 'LocalDB_update_tariffs_log'
        try:
            with self.conn as c:
                c.execute('delete from tariffs')
                c.executemany('insert into tariffs values(?,?,?,?,?,?,?,?)', tariffs)
                print 'LocalDB_update_tariffs1_log'
                
        except sqlite3.OperationalError as e:
            print 'LOCAL DB ERROR', e.__class__.__name__, e

    def get_tariff_by_id(self, tariff_id):
        ret = self.query('select * from tariffs where id = ?', (tariff_id,))
        print 'LocalDB_get_tariff_by_id_log'
        if ret:
            return ret[0]

    def get_tariffs(self):
        print 'LocalDB_get_tariffs_log'
        return self.query('select * from tariffs')

    def update_config(self, config):
        print 'LocalDB_update_config_log'
        with self.conn as c:
            c.execute(('update config set Config=?,id=?,PlaceNum=?,FreeTime=?,PayTime=?,'
                      'TarifName1=?,TarifName2=?,TarifName3=?,TarifName4=?,'
                      'UserStr1=?,UserStr2=?,UserStr3=?,UserStr4=?,'
                      'UserStr5=?,UserStr6=?,UserStr7=?,UserStr8=?,PlaceFree=?'), *config)

    def get_config_strings(self):
        return [s.decode('utf8') for s in self.query('select UserStr1,UserStr2,UserStr3,UserStr4,'
                                                     'UserStr5,UserStr6,UserStr7,UserStr8 from config')[0]]
    def get_footer_config_strings(self):
        print 'LocalDB_get_footer_config_strings_log'
        return [s.decode('utf8') for s in self.query('select UserStr1,UserStr2,UserStr3,UserStr4,'
                                                     'UserStr5,UserStr6,UserStr7 from config')[0]]

    def get_free_time(self):
        try:
            print 'LocalDB_get_free_time_log'
            return int(self.query('select FreeTime from config')[0][0])
        except (ValueError, KeyError):
            print 'LocalDB_get_free_time_err_log'
            return None

    def close_connection(self):
        self.conn.close()
        print "Close local db connection"
        return None
            


class DB(QObject):
    free_places_update = pyqtSignal(int)
    print 'DB_QObject_log'

    STRINGS_UPDATE_INTERVAL = 60  # seconds

    def __init__(self, notify=None, initialize_local_db=False, parent=None):
        QObject.__init__(self, parent)

        self.local = LocalDB(initialize=initialize_local_db)
        self.addr = self.local.get_db_addr()
        self.notify = notify
        self.free_places = 0
        print 'DB_init_log'

    #@measure
    def query(self, q, local=False):
        """
        This is a base function for communication with remote database.
        @param q: str, query to be executed remotely
        @param local: bool, this argument defines whether given query will be duplicated on local database
        @return: None when database returned correct NONE response
                 False when there was an error during database communication or error during query execution
                       Those cases are being explicitly notified using self.notify
                 list of string lists when database responded with some data
        """

        TRY_COUNT = 3

        if local:
            for i in range(TRY_COUNT):
                try:
                    with self.local.connection() as c:
                        #logging.debug('local db query %s' % (q,))
                        c.execute(q)
                        break
                except Exception:
                    print 'local_db_query_exception'
                    #logging.debug('local db query exception %s' % (q,))
                    time.sleep(.100)

        try:
            s = socket.create_connection(self.addr, timeout=20)
            s.send(q)
            if q == "select * from Tariff":
                time.sleep (0.3)
                answer = s.recv(8388608)
            else:
                answer = s.recv(1024)
		print ('db_sock', answer)
		print (q)
            print 'db_socket.create_connection_log'
        except socket.error as e:
            print 'db_socket_error'
            #logging.debug('db socket error %s' % (q,))
            #print e.__class__.__name__, e
            if self.notify:
                self.notify(_("Database Error"), q.decode('utf8', errors='replace'))
                print 'socket.create_connection_err_log'
            return False

        if answer == 'FAIL':
            self.notify(_("Query Error"), q.decode('utf8', errors='replace'))
            return False
        if answer == 'NONE':
            return None

        return [line.split('|') for line in answer.split('\n')]

    def get_card(self, sn):
        apb = self.local.option('apb') == '2'
        return Card.create(self.query('select * from card where CardID = "%s"' % (sn,)), apb=apb)

    def get_ticket(self, bar):
        return Ticket.create(self.query('select * from ticket where bar = "%s"' % (bar,)))

    def get_terminals(self):
        print 'db_get_terminals_log'
        return {
            int(key): TerminalData(title=value.decode('utf8', errors='replace'),
                                   notify=notify,
                                   option=option)
            for key, value, notify, option in self.local.get_terminals()
        }

    def update_terminals(self):
        print 'db_update_terminals_log'
        ret = self.query('select terminal_id,title from terminal')
        if ret:
            self.local.update_terminals(ret)
            print 'db_update_terminals1_log'

    def download_tariffs(self):
        print 'db_reload_tariffs_log'
        free_time = self.get_free_time()
        ret = self.query('select * from Tariff')
        if ret:
            self.local.update_tariffs(ret)
        return filter(lambda x: x is not None, [Tariff.create(t, free_time) for t in self.local.get_tariffs()])

    def get_tariffs(self):
        print 'db_get_tariffs_log'
        free_time = self.get_free_time()
        return filter(lambda x: x is not None, [Tariff.create(t, free_time) for t in self.local.get_tariffs()])

    def get_total_places(self):
        print 'db_get_total_places_log'
        ret = self.query('select PlaceNum from config')
        return int(ret[0][0]) if ret else ret

    def update_free_places(self, diff):
        print 'db_update_free_places_log'
        self.query('UPDATE Config SET PlaceFree = CASE WHEN((PlaceFree + %i <= PlaceNum) AND(PlaceFree + %i >= 0)) '
                   'THEN(PlaceFree + %i) ELSE PlaceFree END' % (diff, diff, diff), local=True)
        free_places, _ = self.local.get_free_places()
        self.free_places_update.emit(free_places)

    def is_new_free_places(self):
        print 'db_is_new_free_places_log'
        free_places = self.get_free_places()
        if free_places == self.free_places:
            return False
        else:
            self.free_places = free_places
            return True

    def get_free_places(self):
        print 'db_get_free_places_log'
        free_places, valid = self.local.get_free_places()
        if not valid:
            answer = self.query('select PlaceFree from Config')
            if answer is False:
                return free_places
            try:
                free_places = int(answer[0][0])
                self.local.update_free_places(free_places)
                self.free_places_update.emit(free_places)
            except (IndexError, KeyError, ValueError, TypeError) as e:
                print 'Incorrect response:', e.__class__.__name__, e
        return free_places

    reasons = {
        1: _('manual').encode('utf8', errors='replace'),
        5: _('auto').encode('utf8', errors='replace')
    }

    def generate_open_event(self,addr, reason, command):
        if not command % 2:
            # close commands should not trigger event generation
            return True

        reason = self.reasons.get(reason, '')
        event_name = _('open').encode('utf8', errors='replace') if command % 2 else ''
        now = datetime.now().strftime(DATETIME_FORMAT)
        print 'db_generate_open_event_log'
        args = (event_name, now, addr, reason)
        return self.query('insert into events values("Event",NULL,"%s","%s",%i,"","%s", \
                          (select PlaceFree from Config),"","")' % args, local=True)

    PASS_QUERY = ('insert into events values("Event",NULL,"{0}","%s",%i,"%s","",\
                  (select PlaceFree from Config),%s, %s)'.format(_('pass').encode('utf8', errors='replace')))

    def generate_pass_event(self, addr, sn, inside):
        direction_name = (_('inside') if inside else _('outside')).encode('utf8', errors='replace')
        now = datetime.now().strftime(DATETIME_FORMAT)
	if inside:
		f = open ('/mnt/ramdisk/number_in.py', 'r')
	else:
		f = open ('/mnt/ramdisk/number_out.py', 'r')
	numm = str('"' + f.read() + '"')
	f.close()
	if inside:
		f = open ('/mnt/ramdisk/number_in.py', 'w')
	else:
		f = open ('/mnt/ramdisk/number_out.py', 'w')
	number = f.write('--------')
	f.close()
        args = (now, addr, direction_name, '"%s"' % (sn), numm)
        print 'db_generate_pass_event_log'
        return self.query(self.PASS_QUERY % args, local=True)

    def update_config(self):
        self.addr = self.local.get_db_addr()
        response = self.query('select * from Config')
        print 'db_update_config_log'
        if response:
            self.local.update_config(response)

    def get_config_strings(self):
        print 'db_get_config_strings_log'
        return self.local.get_config_strings()

    def get_footer_config_strings(self):
        print 'db_get_config_strings_log'
        return self.local.get_footer_config_strings()

    def get_free_time(self):
        print 'db_get_free_time_log'
        return self.local.get_free_time()

    def get_check_header(self):
        print 'db_get_check_header_log'
        return u'<c>\n'.join(self.get_config_strings()[:4]) + u'\n<hr /></c>\n'

    def get_check_footer(self):
        print 'db_get_check_footer_log'
        return u'<c><hr />' + u'\n'.join(self.get_footer_config_strings()[4:]) + u'\n<hr /></c>\n'

    PAYMENT_QUERY = 'insert into Payment values(NULL, "{payment}", {tariff}, {console}, "{operator}", \
                     "{now}", "{id}", {status}, {tariff}, {cost}*100, {units}, "{begin}", "{end}", {price}*100)'

    def generate_payment(self, db_payment_args):
        print 'db_generate_payment_log'
        session = self.local.session()
        operator = session[1] if session is not None else '?'
        now = datetime.now().strftime(DATETIME_FORMAT)

        return self.query(self.PAYMENT_QUERY.format(console=0, operator=operator, status=Ticket.PAID,
                                                    now=now, **db_payment_args), local=True) is None


if __name__ == '__main__':
    import doctest
    print 'doctest_log'
    doctest.testmod()
    print 'testmod_log'
    d = DB()
    print 'd_db_log'
    d.local.session_end()
    print 'session_end_log'
    d.local.session_begin(d.get_card('E7008D750C'))
    print 'd.get_card_log'
    #d.local.session_begin(d.get_card('2A00D146C0'))


    #d.query('delete from ticket')
    #d.query('update ticket set status=5 where bar = "102514265300000029"')
    #d.query('delete from ticket where bar >= "102516091500000030"')
    #d.query('update ticket set timeout="13-10-28 11:40:00" where bar = "102516091500000030"')
    #d.query('update ticket set summdopl = summdopl+1 where bar = "102516091500000030"')
    #d.query('select * from ticket where  bar = "102516091500000030" ')
    #d.query('select * from tariff where id = 2')
    #tariff = d.get_tariffs()[0]
    #t = d.get_ticket('102514265300000029')
    #print t.pay(tariff).explanation()
