def encrypt(bar):
	line = str(bar)
	cng = [0,0,0,0,0,0,0,0,0,0,0,0]
        codepage = [[2,3,7,8,2,5,7,2,8,7,3,2],[9,6,2,2,4,9,8,9,7,1,6,5],[6,9,6,5,3,5,6,8,8,1,5,2],[5,2,2,2,6,9,5,9,3,4,5,3],[7,7,7,5,7,9,8,5,1,2,4,5],[7,1,5,9,9,5,9,2,4,2,2,2],[7,7,6,1,6,9,6,8,9,2,6,5],[7,4,4,8,8,7,4,7,7,7,4,9],[8,3,9,4,7,3,3,6,1,4,4,3],[1,5,1,7,8,6,3,7,2,7,5,5]]
	code = list(line[0:17])
	print(code)
        for i in range(12):
           	cng[i] = int(code[i]) + codepage[int(line[17])][i]
		if cng[i] > 9:
			cng[i] -= 10
	s = [str(k) for k in cng]
	rang = "".join(s)
	print(rang)
	barr = str(rang) + line[12:18]
        return barr

def decrypt(bar):
	line = str(bar)
	cng = [0,0,0,0,0,0,0,0,0,0,0,0]
        codepage = [[2,3,7,8,2,5,7,2,8,7,3,2],[9,6,2,2,4,9,8,9,7,1,6,5],[6,9,6,5,3,5,6,8,8,1,5,2],[5,2,2,2,6,9,5,9,3,4,5,3],[7,7,7,5,7,9,8,5,1,2,4,5],[7,1,5,9,9,5,9,2,4,2,2,2],[7,7,6,1,6,9,6,8,9,2,6,5],[7,4,4,8,8,7,4,7,7,7,4,9],[8,3,9,4,7,3,3,6,1,4,4,3],[1,5,1,7,8,6,3,7,2,7,5,5]]
	code = list(line[0:17])
	print(code)
        for i in range(12):
           	cng[i] = int(code[i]) - codepage[int(line[17])][i]
		if cng[i] < 0:
			cng[i] += 10
	s = [str(k) for k in cng]
	rang = "".join(s)
	print(rang)
	barr = str(rang) + line[12:18]
        return barr
