# -*- coding: utf-8 -*-
import os
from Tkinter import *
import tkMessageBox as mb
import json

config = {}


class MainApp(Tk):
    def start(self):
	
        self.title('GUI')

        self.geometry('400x200+300+200')
        self.resizable(False, False)




        lst_labels = (
            Label(self, font='arial 12', text='IP TVT In ').grid(row=0, column=0, sticky=W),
            Label(self, font='arial 12', text='IP TVT Out ').grid(row=1, column=0, sticky=W),
            Label(self, font='arial 12', text='Port NumberOK In').grid(row=2, column=0, sticky=W),
            Label(self, font='arial 12', text='Port NumberOK Out').grid(row=3, column=0, sticky=W),

        )

        self.ip_tvt_in = StringVar(self)
        self.ip_tvt_out = StringVar(self)
        self.port_numberok_in = StringVar(self)
        self.port_numberok_out = StringVar(self)

        tuple_entrys = (
            Entry(self, font='arial 12', textvariable=self.ip_tvt_in).grid(row=0, column=1, padx=5, pady=5),

            Entry(self, font='arial 12', textvariable=self.ip_tvt_out).grid(row=1, column=1, padx=5, pady=5),
            Entry(self, font='arial 12', textvariable=self.port_numberok_in).grid(row=2, column=1, padx=5, pady=5),
            Entry(self, font='arial 12', textvariable=self.port_numberok_out).grid(row=3, column=1, padx=5, pady=5)
        )

        btn = Button(self, width=20, bg='grey', font='arial 12', text='Задати налаштування',
                     command=self.set_configuration).grid(row=4, column=1, padx=5, pady=5)

        if os.path.exists('config.json'):

            self.configuration()
        else:
            mb.showinfo('Конфігурація', 'Створіть конфігурацію')
	    
            # print(f'dfd {res}')
            # if res != None:
	self.mainloop()

    

    def set_configuration(self):
        config.update({'ip_tvt_in': self.ip_tvt_in.get()})
        config.update({'ip_tvt_out': self.ip_tvt_out.get()})
        config.update({'port_numberok_in': self.port_numberok_in.get()})
        config.update({'port_numberok_out': self.port_numberok_out.get()})

        json_str = json.dumps(config, indent=4)
        with open('config.json', 'w+') as file:
            file.write(json_str)
            mb._show('Конфігурація', 'Конфігурація прошла успішно!')

    def configuration(self):

        with open('config.json', 'r') as file:
            content = file.read()
            config = json.loads(content)

        self.ip_tvt_in.set(config['ip_tvt_in'])
        self.ip_tvt_out.set(config['ip_tvt_out'])
        self.port_numberok_in.set(config['port_numberok_in'])
        self.port_numberok_out.set(config['port_numberok_out'])


if __name__ == '__main__':
    MainApp().start()
