__author__ = 'DAlex'

import serial

class SerialPort(object):
    def __init__(self, name, speed, timeout=0):
        self.ser = None
        self.name = name
        self.speed = speed
        self.timeout = timeout
        self.reconnect()

    def reconnect(self):
        if self.ser is not None:
            self.ser.close()
        try:
            self.ser = serial.Serial(self.name, self.speed, timeout=self.timeout)
            print 'connection to', self.name, 'established'
        except Exception:
            print 'connection to', self.name, 'failed'
            self.ser = None

    @property
    def connected(self):
        return self.ser is not None

    def send(self, *args):
        x = self.ser.write(args[0])
        #if x:
        #    print 'Put:', x
        return x

    def recv(self, *args):
        return self.ser.read(args[0])

    def __del__(self):
        self.ser.close()
