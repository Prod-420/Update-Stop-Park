def hex_to_bin(hexx):
    mass = list(hexx)
    for i in range(len(mass)):
        mass[i] = "{0:04b}".format(int(mass[i], 16))
        print(mass[i])
    return mass

def inc_hex(dest, second):
    print (dest)
    first = int(dest, 16)
    summ = first + second
    dest = hex(summ)
    return dest

def mult_hex(dest):
    first = int(dest, 16)
    summ = first * 2
    dest = hex(summ)
    return dest

def converter(mass):
    result = []
    revers = []
    for i in range(0,len(mass),2):
        dest = hex(0)
        for j in range(4):
            print ("start", dest, " row ", i)
            if mass[i+1][-1] == '1': dest = inc_hex(dest, 1)
            print("after first if", dest)
            if mass[i][-1] == '1': dest = inc_hex(dest, 16)
            print("after second if", dest)
            if j < 3: dest = mult_hex(dest)
            print("after multiply", dest)
            mass[i], mass[i+1] = test(mass[i], mass[i+1])
        result.append(dest)
    for i in reversed(result):
	print("test : ", i)
	if len(i) != 3:
        	revers.append(i.split('x')[-1])
	else:
		revers.append("0" + str(i.split('x')[-1]))
    return (revers[0] + revers[1] + revers[2] + revers[3])

def test(mass1, mass2):
    calc = mass1 + mass2
    calc = int(calc, 2)
    calc = calc // 2
    calc = '{0:08b}'.format (calc)
    print (calc)
    return calc[0:4],calc[4:8]

POLYNOMIAL = 0x1021
PRESET = 0x7A38

def _initial(c):
    crc = 0
    c = c << 8
    for j in range(8):
        if (crc ^ c) & 0x8000:
            crc = (crc << 1) ^ POLYNOMIAL
        else:
            crc = crc << 1
        c = c << 1
    return crc

_tab = [ _initial(i) for i in range(256) ]

def _update_crc(crc, c):
    cc = 0xff & c

    tmp = (crc >> 8) ^ cc
    crc = (crc << 8) ^ _tab[tmp & 0xff]
    crc = crc & 0xffff
    print (crc)

    return crc

def crc(str):
    crc = PRESET
    for c in str:
        crc = _update_crc(crc, ord(c))
    return crc

def crcb(*i):
    crc = PRESET
    for c in i:
        crc = _update_crc(crc, c)
    return crc

def checkCRC(message):
    #CRC-16-CITT poly, the CRC sheme used by ymodem protocol
    poly = 0x1021
    #16bit operation register, initialized to zeros
    reg = 0
    #pad the end of the message with the size of the poly
    message = str(message) + '\x00\x00'
    #for each bit in the message
    for byte in message:
        mask = 0x80
        while(mask > 0):
            #left shift by one
            reg<<=1
            #input the next bit from the message into the right hand side of the op reg
            if ord(byte) & mask:
                reg += 1
            mask>>=1
            #if a one popped out the left of the reg, xor reg w/poly
            if reg > 0xffff:
                #eliminate any one that popped out the left
                reg &= 0xffff
                #xor with the poly, this is the remainder
                reg ^= poly
    return reg

def seven_to_four (hex_mass, mass):
    global PRESET
    PRESET = int(mass[6] + mass[7] + mass[4] + mass[5], 2)
    crc =hex(crcb(hex_mass[0], hex_mass[1], hex_mass[2], hex_mass[3], hex_mass[4], hex_mass[5], hex_mass[6]))
    if len(crc) < 6:
        crc = "0x0"+ crc[2:5]
    PRESET = int(mass[2] + mass[3] + mass[0] + mass[1], 2)
    crc1 =hex(crcb(hex_mass[0], hex_mass[1], hex_mass[2], hex_mass[3], hex_mass[4], hex_mass[5], hex_mass[6]))
    if len(crc1) < 6:
        crc1 = "0x0"+ crc1[2:5]
    print(crc, crc1)
    hexx = crc1[4:6]+ crc1[2:4] + crc[4:6] + crc[2:4]
    print (hexx)
    return hexx


def main(hexx):
    hex_mass = list(hexx[0:7])
    mass = hex_to_bin(hexx)
    k = 0
    for i in range(0, len(hexx), 2):
        hex_mass[k] = int(mass[i] + mass[i + 1], 2)
        k += 1
    if (len(hexx) == 14):
        hexx = seven_to_four(hex_mass, mass)
        mass = hex_to_bin(hexx)
    result = converter(mass)
    if len(result) < 8:
        result = "0"+result
    print("result",result.upper())
    return result.upper()

if __name__ == "__main__":
    main()
