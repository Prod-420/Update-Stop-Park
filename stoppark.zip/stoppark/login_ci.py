# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'login.ui'
#
# Created: Tue Jan 14 15:36:39 2020
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Login_Form(object):
    def setupLogin(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(700, 252)
        self.label = QtGui.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(40, -30, 791, 281))
	self.label.setText(_translate("Form", "Піднесіть майстер ключ", None))
        font = QtGui.QFont()
        font.setPointSize(36)
        self.label.setFont(font)
        self.label.setObjectName(_fromUtf8("label"))
	self.pushButton3 = QtGui.QPushButton(Form)
        self.pushButton3.setGeometry(QtCore.QRect(520, 180, 163, 32))
        self.pushButton3.setObjectName(_fromUtf8("pushButton"))
        self.retranslateLogin(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateLogin(self, Form):
        Form.setWindowTitle(_translate("Form", "Login", None))
        self.label.setText(_translate("Form", "Піднесіть майстер ключ", None))
	self.pushButton3.setText(_translate("Form", "Зчитати майстер ключ", None))

