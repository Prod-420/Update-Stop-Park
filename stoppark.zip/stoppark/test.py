from asyncore import dispatcher, dispatcher_with_send, loop
from socket import AF_INET, SOCK_STREAM
from database import Model
from datetime import datetime
from os import path, remove
import time
import logging
import logging.config
import re
from subprocess import Popen
from sqlite3 import connect as sqlite3_connect
from sqlitebck import copy as sqlitebck_copy
from threading import Thread, Event

LOCAL_DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'

#ADDR = getoutput("/sbin/ifconfig").split("\n")[1].split()[1][5:] , 101

logging.config.dictConfig({
 'version': 1,    # Configuration schema in use; must be 1 for now
 'formatters': {
     'standard': {
         'format': ('%(asctime)s %(host)-15s '
                    '%(levelname)-8s %(message)s')}},

 'handlers': {'mid': { 'backupCount': 10,
                       'class': 'logging.handlers.RotatingFileHandler',
                       'filename': 'data/mid.log',
                       'formatter': 'standard',
                       'level': 'DEBUG',
                       'maxBytes': 10000000 }
             },
 # Specify properties of the root logger
 'root': {
          'level': 'DEBUG',
          'handlers': ['mid']
 },
})

databaseFilename = 'data/db.db3'
databaseBackup = 'data/backup/backup.db3'


def backup_database(database_filename, database_backup):
    connect_db = sqlite3_connect(database_filename)
    connect_db_backup = sqlite3_connect(database_backup)
    sqlitebck_copy(connect_db, connect_db_backup)
    connect_db.close()
    connect_db_backup.close()
    print 'backup created'

backup_database(databaseFilename, databaseBackup)



