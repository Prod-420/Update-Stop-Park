# -*- coding: utf-8 -*-
# encoding: utf-8
import re
from PyQt4.QtCore import QObject, pyqtSignal
from threading import Thread, Event
from gevent import spawn, sleep, get_hub, socket
from gevent.queue import Queue
from safe_socket import SafeSocket
from report import Report
from db import DB, Ticket, Card, LocalDB
from datetime import datetime
from config import DISPLAY_PEER, TICKET_PEER, CARD_PEER, PRINTER_PEER, FISCAL_PRINTER_PEER, \
    LOCAL_DATETIME_FORMAT, DATE_FORMAT
from i18n import language
import traceback
import sys
from serial_port import SerialPort
import coding
import cam
import mifare_coding
# from os import wait  # kill zombie process

_ = language.ugettext


class TicketReader(object):
    def __init__(self, peer, new_payable):
        self.regex = re.compile(r'(;(?P<bar>\d+)\?(\r\n)?)')
        self.peer = peer
        self.new_payable = new_payable
        self.ticket = None

    def triger(bar):
	handle_bar(self, bar, db, emit)

    def handle_bar(self, bar, db, emit):
        # print 'handle_bar', bar
        self.ticket = db.get_ticket(bar)
        if self.ticket is None:
            try:
                f1 = open ('/mnt/ramdisk/dts11.py', 'r')
                dts11 = f1.read()
                f1.close()
            except:
                print ("dts_error")
            if Ticket.register(db, str(bar)):
                if dts11 == "1":
                    cam.reg_bar_nom(bar)
                self.ticket = db.get_ticket(bar)
        if self.ticket:
            if emit:
                self.new_payable.emit(self.ticket, db.get_tariffs())
            return self.ticket

    def __call__(self, db):

        if sys.platform == 'linux2':
            sock = SerialPort(self.peer[0], self.peer[1])
        else:
            sock = SafeSocket(self.peer)

        buf = ''
        while True:
            buf += sock.recv(128)
            if buf == '':
                sleep(0.5)
            else:
                print 'buf', buf
                if buf[0] != ';':
                    buf = ''
                else:

                    last_index = 0
                    for match in self.regex.finditer(buf):
                        last_index = match.span()[1]
                        bar = match.group('bar')
                        if len(bar) < 18:
                            continue
                        print 'ticket_buf', buf
                        self.handle_bar(bar, db, emit=True)

                    if last_index != 0:
                        buf = buf[last_index:]
                    else:
                        buf = ''


class CardReader(object):

    readerEvent = Event()
    def __init__(self, peer, new_payable, new_operator, new_card):
        self.regex = re.compile(r'(;(?P<sn>[A-Z\d]+)\?)')
        self.peer = peer
        self.new_payable = new_payable
        self.new_operator = new_operator
        self.new_card = new_card
        self.buf = ''
        self.card = None

    def handle_card(self, sn, db):
        print 'handle_card', sn
        self.card = db.get_card(sn)
        if self.card:
            if self.card.type in [Card.CLIENT]:
                self.new_payable.emit(self.card, db.get_tariffs())
            if self.card.type in [Card.CASHIER, Card.ADMIN]:
                self.new_operator.emit(self.card)
        elif self.card is not None:
            self.card = Card.config_card()
            self.new_operator.emit(self.card)
        else:
            self.new_card.emit(sn)

    def card_read_loop(self, sock):
        while True:
            sock.send('n')
            sleep(1)
            if self.readerEvent.is_set():
                sleep(2)
                self.readerEvent.clear()
            # print 'reader_n_log'

    def __call__(self, db):

        if sys.platform == 'linux2':
            sock = SerialPort(self.peer[0], self.peer[1])
        else:
            sock = SafeSocket(self.peer)

        spawn(self.card_read_loop, sock)
        buf = ''
        while True:
            buf += sock.recv(128)
            if buf == '':
                sleep(0.3)
            else:
                print ('buf exec', buf)
                if (len(buf)) == 16:
                    if buf[1] == '0' and buf[2] == '0':
                        print ("buff", buf[7:-1])
                        after = mifare_coding.main(buf[7:-1])
                        buf = ";00" + after + "?"
                    else:
                        after = mifare_coding.main(buf[1:-1])
                        buf = ";00" + after + "?"
                self.readerEvent.set()
                if buf[0] != ';' or buf[0] == '1':
                    buf = ''
                else:
                    print("debug 1")
                    last_index = 0
                    for match in self.regex.finditer(buf):
                        print ("debug 2")
                        last_index = match.span()[1]
                        bar = match.group('sn')
                        print 'handle_card_db'
                    bar = buf[1:-1]
                    print("bar", bar)
                    self.handle_card(bar, db)
                    buf = ""
                    buf = buf[last_index:]


class FiscalPrinter(object):
    seq = 0x20

    def __init__(self, peer=None):

        self.peer = peer
        self.preamble = 0x01
        self.eot = [0x04]
        self.enq = [0x05]
        self.bcc = [0x00, 0x00, 0x00, 0x00]
        self.ext = [0x03]
        self.messege = []
        self.data = []
        self.sock = None
        self.enable = False
        self.selected_packet = False
        self.operator = ""
        self.result = False
        self.cmd = []
        self.error_code = []
        self.payload_data = []
        self.status = []
        self.without_error = [0x30, 0x30, 0x30, 0x30]
        self.rcv_data = ""
        self.sock = None
        self.err_msg = ""
        self.operator_reg_state = False
        self.cash = 0

    def send(self, data):
        self.selected_packet = False
        self.data = []
        self.err_msg = ""
        try:
            self.sock.send(data)
        except:
            pass

    def pack_data(self, cmd, data_str, pwd_str=u"000000"):

        try:
            data_str = unicode(data_str)
            data_str = data_str.encode('cp1251')

            data = map(ord, data_str)
            pwd = map(ord, pwd_str)

            if self.__class__.seq < 0x20 and self.__class__.seq >= 0x7F:
                self.__class__.seq = 0x20
            else:
                self.__class__.seq += 1
            lenght = 1 + 1 + len([cmd]) + len(pwd) + 0x01 + len(data) + len(self.enq) + 0x20
            self.messege = [lenght] + [self.__class__.seq] + [cmd] + pwd + [0x3B] + data + self.enq
            summ = 0
            for i in self.messege:
                summ = summ + i

            bcc = [(summ >> i & 0x0f) + 0x30 for i in (16, 8, 4, 0)]
            self.messege.insert(0, self.preamble)
            self.messege = self.messege + bcc + self.ext

            data = ""
            for i in self.messege:
                data += chr(i)

        except Exception, err:
            print traceback.format_exc()
            data = '\x00'
        finally:
            return data

    def __call__(self):
        #self.sock = SafeSocket(self.peer)
        if sys.platform == 'linux2':
            sock = SerialPort(self.peer[0], self.peer[1])
        else:
            sock = SafeSocket(self.peer)

        # while True:
        #    self.rcv_data = sock.recv(128)
        #    self.data += [ord(ch) for ch in self.rcv_data]
            #print("rcv data")
            #print(self.data)

    def wait_answer(self):

        self.result = False
        self.cmd = []
        self.error_code = []
        self.payload_data = []
        self.status = []

        for i in range(20):
            print("iteration = " + str(i) + self.rcv_data + "\n")
            sleep(0.1)
            if self.select_packet():
                print("selected_packet", self.data)
                return True
        self.err_msg = "rx_buff_empty_err"
        return False

    def select_packet(self):
        try:
            preamble = self.data.index(self.preamble)
            self.data = self.data[preamble:]
            ext = self.data.index(self.ext[0])
            self.data = self.data[:ext + 1]
            self.err_msg = ""
            return True
        except ValueError as e:
            self.err_msg = "select_packet_err"
            print (e)
            return False

    def check_bcc(self, data):
        try:
            recv_bcc = data[-5:-1]
            raw_data = data[1:-5]
            summ = 0
            for i in raw_data:
                summ += i

            calc_bcc = [(summ >> i & 0x0f) + 0x30 for i in (16, 8, 4, 0)]

            if recv_bcc == calc_bcc:
                self.err_msg = ""
                return True
            else:
                self.err_msg = "check_bcc_err"
                return False
        except Exception as e:
            self.err_msg = "check_bcc_err"
            print(e)
            return False

    def get_payload_data(self, data):
        try:
            data_len = data[1] - 0x20 - 1 - 1 - 1 - 5 - 1 - 6 - 1
            self.cmd = data[3]
            self.error_code = data[4:8]
            self.payload_data = []
            if data_len > 0:
                self.payload_data = data[9: 9 + data_len]
            self.status = data[-12:-6]
            self.result = True
            self.err_msg = "ok"
            return self.result
        except Exception as e:
            print (e)
            self.result = False
            self.err_msg = "get_payload_data_err"
            return self.result

    def receive_data(self):
        if self.wait_answer() is True:
            if self.check_bcc(self.data) is True:
                if self.get_payload_data(self.data) is True:
                    if self.error_code == self.without_error:
                        return True
        print(self.error_code)
        return False

    def zx_report(self, type):
        print ("zx_report"+type)
        data = type + u";"
        msg = self.pack_data(0xA1, data)
        self.send(msg)
        if self.receive_data():
            return True
        return False

    comm = """
        def get_time(self):
            print ("get_time")
            result = False
            msg = self.pack_data(0x21, u"")
            self.send(msg)
            try:
                if self.receive_data():
                    datatimestr = ""
                    for i in self.payload_data:
                        datatimestr += chr(i)

                    day = datatimestr[:2]
                    print('day=' + day)
                    month = datatimestr[2:4]
                    print('month=' + month)
                    year = datatimestr[4:6]
                    print('year=' + year)
                    hour = datatimestr[7:9]
                    print('hour=' + hour)
                    minute = datatimestr[9:11]
                    print('minute=' + minute)

                    from subprocess import Popen
                    new_datetime = datetime(year=int(year)+2000,
                                            month=int(month),
                                            day=int(day),
                                            hour=int(hour),
                                            minute=int(minute))
                    arg = new_datetime.strftime('%m%d%H%M%Y')
                    Popen(['date', arg])

                    print("Update time successfully")
                    result = True
            except Exception, err:
                print traceback.format_exc()
            finally:
                return result
        """

    def cash_operation(self, cash):
        data = self.operator + u";" + cash + u";"
        msg = self.pack_data(0x6E, data)
        self.send(msg)
        if self.receive_data():
            cash_chr = self.payload_data[:len(self.payload_data)-1]
            cash_str = ""
            for i in cash_chr:
                cash_str += chr(i)
            self.cash = "%0.2f" % float(cash_str)
            print(self.cash)
            return True
        return False

    def end_session(self, data):
        if self.cash_operation(u"0.00"):
            cash = u"-" + unicode(str(self.cash))
            if self.cash_operation(cash):
                self.zx_report(u"1")
                sleep(2)
                self.zx_report(u"0")
                return True
        return False

    def open_fiscal_receipt(self, cashbox, receipt_type):
        data = self.operator + u";" + cashbox + u";" + receipt_type + u";"
        return self.pack_data(0x63, data)

    def close_fiscal_receipt(self):
        display_enable = u"1"
        data = display_enable + u";"
        return self.pack_data(0x65, data)

    def add_articul(self, goods_code, goods_name, tax_group, department_number, modifier, units_name):
        data = goods_code + u";" + goods_name + u";" + tax_group + u";" + department_number + u";" + modifier + u";" + units_name + u";"
        return self.pack_data(0x24, data)

    def sell_item(self, goods_code, amount, cost):
        data = goods_code + u";" + u"%0.3f" % float(amount) + u";" + u"%0.2f" % float(cost) + u";"
        return self.pack_data(0x64, data)

    def print_total(self):
        display_enable = u"1"
        data = display_enable + u";"
        return self.pack_data(0x6D, data)

    def pay(self, cash):
        pay_type = u"0"
        data = pay_type + u";" + u"%0.2f" % cash + u";"
        return self.pack_data(0x67, data)

    def cancel_receipt(self):
        msg = self.pack_data(0x6B, u"0;")
        self.send(msg)
        self.receive_data()

    def read_operator_property(self, operator):
        data = operator + u";"
        print(data)
        return self.pack_data(0x30, data)

    def register_operator(self, operator, fio):
        msg = self.read_operator_property(operator)
        self.send(msg)
        if self.receive_data():
            return True

        msg = self.add_operator(operator, fio)
        self.send(msg)
        if self.receive_data():
            return True
        return False

    def add_operator(self, operator, fio):
        data = operator + u";" + u"000000" + u";" + fio + u";"
        return self.pack_data(0x2F, data)

    def print_fiscal_receipt(self, cashbox_number, receipt_type, goods_code, goods_name, tax_group,
                             department_number, modifier, units_name, amount, cost):
        try:
            print("print_fiscal_receipt")
            msg = self.open_fiscal_receipt(cashbox_number, receipt_type)
            print("open_fiscal_receipt")
            self.send(msg)
            if self.receive_data():
                msg = self.add_articul(goods_code, goods_name, tax_group, department_number, modifier, units_name)
                print("add_articul")
                self.send(msg)
                if self.receive_data():
                    msg = self.sell_item(goods_code, amount, cost)
                    print("sell_item")
                    self.send(msg)
                    if self.receive_data():
                        msg = self.print_total()
                        print("print_total")
                        self.send(msg)
                        if self.receive_data():
                            msg = self.pay(amount * cost)
                            print("pay")
                            self.send(msg)
                            if self.receive_data():
                                msg = self.close_fiscal_receipt()
                                print("close_fiscal_receipt")
                                self.send(msg)
                                if self.receive_data():
                                    print("print fiscal receipt successfully")
                                    return True

        except Exception, err:
            print traceback.format_exc()
        print("print fiscal receipt not successfully")
        raise NameError('print_fiscal_receipt_error')

    def command_table(self, cmd):
        return {
            0: self.zx_report,
            1: self.cash_operation,
            2: self.end_session
        }[cmd]

    def error_parser(self):

        if len(self.error_code) == 0:
            error_msg = _('Device does not answer')
        else:
            error_str = ''
            for i in self.error_code:
                error_str += chr(i)

            try:
                error = eval("0x" + error_str)
            except SyntaxError:
                return ''

            error_msg = {
                0x020A: _('Article / Cashier / .. with this code is not found'),
                0x0905: _('Since the beginning of the change has been more than 24 hours'),
                0x0407: _('Change is closed but not nulled')
            }.get(error)

            if error_msg is None:
                error_msg = "0x" + error_str

        return error_msg


class DisplayLoop(object):
    def __init__(self, peer):
        self.peer = peer
        self.queue = None

    def time_loop(self, sock):
        line_length = 20
        date_format = '%d/%m/%Y'     # _('%x')
        time_format = _('%H:%M:%S')  # _('%X')
        while True:
            now = datetime.now()
            self.display(sock, [
                now.strftime(date_format).center(line_length),
                now.strftime(time_format).center(line_length)
            ])
            sleep(1)
            """try:
                wait()            # every sec kills child processes to prevent zombie.
            except OSError as e:
                print e"""

    def __call__(self):
        self.queue = Queue()

        if sys.platform == 'linux2':
            sock = SerialPort(self.peer[0], self.peer[1])
        else:
            sock = SafeSocket(self.peer)

        # '\x02\x05\x53\x3c\x03' set russian character set, this command is redundant for already configured display
        sock.send('\x1b\x40' '\x02\x05\x53\x3c\x03' '\x0c')  # initialize display and clear screen
        sock.reconnect()
        sock.send('\x1b\x40' '\x02\x05\x53\x3c\x03' '\x0c')  # initialize display and clear screen
        time_loop = spawn(self.time_loop, sock)
        while True:
            messages = self.queue.get()
            if messages is None:
                if time_loop is None:
                    time_loop = spawn(self.time_loop, sock)
            else:
                if time_loop is not None:
                    time_loop.kill()
                    time_loop = None
                self.display(sock, messages)

    @staticmethod
    def display(sock, messages):
        messages = [message.encode('cp866', errors='replace') for message in messages]
        # set cursor at given position and send each message
        [sock.send('\x1b\x6c\x01' + chr(i + 1) + message + ' ' * (20 - len(message))) for i, message in
         enumerate(messages)]
        # print 'display_loop_log'


def async(method):
    """async decorator that wraps up self.async.send() call during async operations"""

    def async_wrapper(self, *args, **kw):
        print 'ex_async_wrapper_log'
        self.queue.put(lambda: method(self, *args, **kw))
        self.async.send()

    return async_wrapper


class Executor(QObject):
    new_payable = pyqtSignal(QObject, list)
    new_operator = pyqtSignal(QObject)
    payment_processed = pyqtSignal()
    payment_error = pyqtSignal()
    tariffs_updated = pyqtSignal(list)
    terminals_notification = pyqtSignal(dict)
    notify = pyqtSignal(str, str)
    session_begin = pyqtSignal(str, str, str)
    session_end = pyqtSignal()
    report = pyqtSignal(object)
    option_notification = pyqtSignal(str, str)
    result_fiscal_operation = pyqtSignal()
    open_terminal_after_pay = pyqtSignal()
    new_card = pyqtSignal(str)

    def __init__(self, parent=None):
        QObject.__init__(self, parent)
        self.thread = Thread(name='executor_loop', target=self._loop)
        self.async = None
        self.db = None
        self.queue = None
        self._card = None

        self.display_loop = DisplayLoop(DISPLAY_PEER)
        self.ticket_reader = TicketReader(TICKET_PEER, self.new_payable)
        self.card_reader = CardReader(CARD_PEER, self.new_payable, self.new_operator, self.new_card)
        self.fiscal_printer = FiscalPrinter(FISCAL_PRINTER_PEER)

        # self.timer = SyncTime()

    def _tariff_updater(self):
        while True:
            self.tariffs_updated.emit(self.db.get_tariffs())
            sleep(60)

    def _async_processor(self):
        hub = get_hub()
        while True:
            hub.wait(self.async)

    def _loop(self):
        self.async = get_hub().loop.async()
        self.async.start(lambda: None)

        self.queue = Queue()
        self.db = DB(notify=lambda title, msg: self.notify.emit(title, msg), initialize_local_db=True)

        spawn(self._async_processor)
        spawn(self.ticket_reader, self.db)
        spawn(self.card_reader, self.db)
        spawn(self.display_loop)
        spawn(self.fiscal_printer)
        # spawn(self.timer)

        session = self.db.local.session()
        print session
        if session is not None:
            sn, operator, access, begin, end = session
            if end is None and access == 'operator':
                self.emit_session_begin(sn, operator.decode('utf8', errors='replace'), access)
            else:
                self.emit_session_begin('system', 'system', 'admin')

        while True:
            print 'ex_self.queue.get_log'
            action = self.queue.get()

            if action is not None:
                if callable(action):
                    action()
            else:
                # [greenlet.kill() for greenlet in greenlets]
                break

        print 'reader loop completed'

    def start(self):
        self.thread.start()

    @staticmethod
    def barcode_replace(match):
        bar = match.group('bar')
        result = ('\n\x1ba\x31\x1dw\x02\x1d\x68\x70\x1dk\x48' + chr(len(bar)) + bar + bar + '\n\x1ba\x30')
        return result

    BARCODE_REPLACE_REGEX = re.compile(r'<<(?P<bar>\d+)>>')

    @async
    def to_printer(self, message):
        if sys.platform == 'linux2':
            printer = SerialPort(PRINTER_PEER[0], PRINTER_PEER[1], timeout=0)
        else:
            printer = SafeSocket(PRINTER_PEER, reconnect_interval=0.1, attempt_limit=2)

        if not printer.connected:
            print 'Cannot print'
            return
        message = message.encode('cp1251', errors='replace')
        message = message.replace('<b>', '\x1d!\x01')
        message = message.replace('</b>', '\x1d!\x00')
        message = message.replace('<s>', '\x1d!\x21')
        message = message.replace('</s>', '\x1d!\x00')
        message = message.replace('<c>', '\x1ba\x31')
        message = message.replace('</c>\n', '\n\x1ba\x30')
        message = message.replace('</c>', '\x1ba\x30')
        message = message.replace('<hr />', '-' * 48)
        message = re.sub(self.BARCODE_REPLACE_REGEX, self.barcode_replace, message)
        message += '\n' * 6 + '\x1d\x56\x01'
        printer.send(message)

    @async
    def fiscal_printer_handler(self, cmd, data):
        if self.fiscal_printer.enable:
            if self.fiscal_printer.command_table(cmd)(data) is False:
                self.notify.emit(_('Fiscal printer error'), self.fiscal_printer.error_parser())
                # self.notify.emit(self.fiscal_printer.err_msg,  str(self.fiscal_printer.data))
        if cmd != "end_session_cmd":
            self.result_fiscal_operation.emit()

    @async
    def handle_bar(self, bar, emit=True, to_printer=False):
        ticket = self.ticket_reader.handle_bar(bar, self.db, emit=emit)
        if to_printer:
            self.to_printer(ticket.to_string_check(self.db))

    @async
    def update_tariffs(self):
        print 'ex_update_tariffs_log'
        self.tariffs_updated.emit(self.db.download_tariffs())

    @async
    def insert_card(self, card_num, card_fam):
        if card_num[:5] != 'empty':
            if card_num[:5] == 'ascii':
                self.notify.emit(_('Add card error title'), _('Add card ascii'))
            else:
                card = self.db.get_card(card_num)
                if card:
                    self.notify.emit(_('Add card error title'), _('Add card exist'))
                else:
                    now = datetime.now().strftime(DATE_FORMAT)
                    s = u'insert into Card values("Card",NULL,2, "%s","%s","%s","00-00-00 00:00:00","00-00-00 00:00:' \
                        u'00",NULL,NULL,"%s",NULL,NULL,NULL,NULL,1,NULL,NULL,NULL)' % (card_num, now, now, card_fam)
                    self.db.query(s.encode('utf8'))
                    sleep(1)
                    card = self.db.get_card(card_num)
                    if card:
                        self.notify.emit(_('Add card title'), _('Add card complete'))
        else:
            self.notify.emit(_('Add card error title'), _('Add card empty'))

    def emit_terminals_notification(self):
        print 'ex_emit_terminals_notification_log'
        self.terminals_notification.emit(self.db.get_terminals())

    @async
    def notify_terminals(self):
        print 'ex_notify_terminals_log'
        self.emit_terminals_notification()

    @async
    def update_terminals(self):
        """ обновляем список терминалов для админа и оператора """
        print 'ex_update_terminals_log'
        self.db.update_terminals()
        self.emit_terminals_notification()

    @async
    def update_terminals_list(self):
        print 'ex_update_terminals_list_log'
        self.db.update_terminals()

    @async
    def pay(self, payment):
        try:
            if self.fiscal_printer.enable:
                _amount = float(payment.db_payment_args["units"])
                _cost = float(payment.db_payment_args["cost"])
                if _amount*_cost > 0:
                    self.fiscal_printer.print_fiscal_receipt(cashbox_number=u"0",
                                                             receipt_type=u"0",
                                                             goods_code=unicode(str(payment.db_payment_args["tariff"])),
                                                             goods_name=unicode(payment.tariff.title),
                                                             tax_group=u"0",
                                                             department_number=u"0",
                                                             modifier=u"00",
                                                             units_name=unicode(payment.check_interval[:3]) if
                                                             hasattr(payment, "check_interval") else u"1",
                                                             amount=_amount,
                                                             cost=_cost
                                                             )

            # open exit terminal automatically if is payment of barcode ticket DAlex 2014/09/18
            from ticket import TicketPayment, TicketExcessPayment
            if payment.execute(self.db):
                if self.db.local.option("aeap") == "2":
                    if isinstance(payment, TicketPayment) or isinstance(payment, TicketExcessPayment):
                        self.open_terminal_after_pay.emit()
            if payment.price != 0:
                self.to_printer(payment.check(self.db))
            self.payment_processed.emit()
        except Exception as e:
            print e
            print traceback.format_exc()
            self.payment_error.emit()
            if self.fiscal_printer.enable:
                self.fiscal_printer.cancel_receipt()
                self.notify.emit(_('Fiscal printer error'), self.fiscal_printer.error_parser())

    @async
    def display(self, message):
        self.display_loop.queue.put(message)

    def emit_session_begin(self, sn, fio, access):
        self.session_begin.emit(sn, fio, access)
        # self.get_fiscal_printer_state()
        # if access == "operator":
        #    self.fiscal_printer.operator = str(eval("0x" + sn) & 0xFF)
        self.emit_all_options()

    def cashier_registration(self, card):
        result = False
        self.fiscal_printer.operator = str(eval("0x" + card.sn) & 0xFF)
        try:
            if self.fiscal_printer.register_operator(self.fiscal_printer.operator, card.sn) is True:
                result = True
            else:
                self.notify.emit(_('Fiscal printer error'), self.fiscal_printer.error_parser())
        except Exception as e:
            print e
            print traceback.format_exc()
        finally:
            return result

    @async
    def update_fiscal_printer_state(self):
        if self.db.local.option("rpt") == "2":
            self.fiscal_printer.enable = True
        else:
            self.fiscal_printer.enable = False

    def get_fiscal_printer_state(self):
        self.update_fiscal_printer_state()
        return self.fiscal_printer.enable

    @async
    def begin_session(self, card):
        print 'begin_session_db.update_config'
        self.db.update_config()
        print 'begin_session_local.session_begin'
        self.db.local.session_begin(card)
        print 'begin_session_emit_session_begin'
        self.emit_session_begin(card.sn, card.fio, card.access)
        print 'begin_session_end'

    @async
    def end_session(self):
        self.fiscal_printer_handler(2, "")
        print 'end_session'
        # self.update_terminals()
        self.db.update_terminals()
        self.db.update_config()
        self.db.local.session_end()
        self.session_end.emit()

    @async
    def generate_report(self):
        print 'generate_report'
        self.report.emit(Report(self.db))

    @async
    def set_option(self, key, value):
        self.db.local.set_option(str(key), str(value))

    def emit_option(self, key):
        self.option_notification.emit(key, self.db.local.option(key))

    def emit_all_options(self):
        for key, value in self.db.local.all_options():
            self.option_notification.emit(key, value)

    @async
    def notify_option(self, key):
        self.emit_option(key)

    @async
    def notify_all_options(self):
        self.emit_all_options()

    @async
    def stop(self):
        self.queue.put(None)


class SyncTime(object):
    def __init__(self):
        # self.thread = None
        # self.local = LocalDB(initialize=False)
        self.peer = None
        try:
            self.db = LocalDB(initialize=False)
            self.peer = self.db.get_db_addr()
            self.db.close_connection()
        except Exception as err:
            print 'ERROR:', err

    def get_time_from_server(self):
        if self.peer is None:
            self.db = LocalDB(initialize=False)
            self.peer = self.db.get_db_addr()
            self.db.close_connection()

        s = socket.create_connection(self.peer, timeout=20)
        # s = SafeSocket(self.peer)
        s.send('>>>get_time:[%s]' % datetime.now().strftime(LOCAL_DATETIME_FORMAT))
        answer = s.recv(1024)
        # dt1 = None
        if answer and answer is not None:
            dt1 = None
            try:
                dt1 = datetime.strptime(answer, LOCAL_DATETIME_FORMAT)
            except ValueError as err:
                print 'ERROR:', err
            finally:
                return dt1

    def __call__(self):
        from subprocess import Popen
        while True:
            try:
                new_time = self.get_time_from_server()
                arg = new_time.strftime('%m%d%H%M%Y.%S')
                if sys.platform == 'linux2':
                    Popen(['date', arg])
                else:
                    print new_time
            except Exception as err:
                print 'ERROR:', err
            finally:
                sleep(60)   # sleep(60*60) Kosterin 21/01/2015
