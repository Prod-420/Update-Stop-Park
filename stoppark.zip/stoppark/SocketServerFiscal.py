import socket
import os
import time


def PRINT_CHECK(cost, cost_per_hour):
    open_check = "./fiscal.out 100 63 000000 01 1 0"
    units = int(cost) / int(cost_per_hour)
    print ("cost, cost_per_hour, units",str(cost), str(cost_per_hour), str(units))
    untis_check = "./fiscal.out 101 64 000000 000010 " + str(units) + ".000 " + str(cost_per_hour) + ".00"
    summary = "./fiscal.out 102 6D 000000 1"
    payed = "./fiscal.out 103 67 000000 1 " + str(cost) + ".00"
    close_check = "./fiscal.out 104 65 000000 1"
    clear_display = "./fiscal.out 105 81 000000 0 1 1"
    print_client = "./fiscal.out 106 81 000000 1 5 GO-PAY_v0.1"
    print_client2 = "./fiscal.out 107 81 000000 2 4 KSM-TECHNOPARK"
    print(open_check +"\n"+untis_check +"\n"+summary +"\n"+payed +"\n"+close_check +"\n")
    os.system(open_check)
    time.sleep(1)
    os.system(untis_check)
    time.sleep(1)
    os.system(summary)
    time.sleep(1)
    os.system(payed)
    time.sleep(1)
    os.system(close_check)
    time.sleep(3)
    os.system(clear_display)
    time.sleep(1)
    os.system(print_client)
    os.system(print_client2)


def parse(str):
    str = str.decode('utf-8')
    lst = str.split(',')
    return lst

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(('0.0.0.0', 303))
sock.listen(10)

while True:
    conn, addr = sock.accept()
    print('connected:', addr)
    data = conn.recv(1024)
    print(data.encode('utf-8'))
    if len(data) > 0:
        conn.sendall("OK".encode('utf-8'))
        lst = parse(data)
        if(len(lst) == 2):
            PRINT_CHECK(lst[0], lst[1])
    conn.close()
