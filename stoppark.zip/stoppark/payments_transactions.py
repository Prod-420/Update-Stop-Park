__author__ = 'VIC'

# -*- coding: utf-8 -*-
from PyQt4 import uic
from PyQt4.QtCore import QObject, pyqtSignal, pyqtSlot, QUrl
from PyQt4.QtGui import QWidget, QDialog
from keyboard import Keyboard
from keyboard import TicketInput, UnitsInput
from i18n import language

_ = language.ugettext


class PaymentsTransactions(QWidget):

    # send_cmd_to_fiscal_printer = pyqtSignal(int, str)

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        self.ui = uic.loadUiType('payments_transactions.ui')[0]()
        self.ui.setupUi(self)

        # self.ui.x_report.clicked.connect(self.x_report)
        # self.ui.z_report.clicked.connect(self.z_report)
        # self.ui.keyboard.clicked.connect(self.show_keyboard)
        # self.ui.service_input.clicked.connect(self.put_cash)
        # self.ui.service_output.clicked.connect(self.take_cash)
        self.ui.progress.setVisible(False)

        self.set_enable_btn = None

    def show_keyboard(self):
        Keyboard.show()
        self.ui.data.setFocus(True)

    def x_report(self):
        self.set_enable_btn = self.ui.x_report.setEnabled
        self.send_data(0, "1")

    def z_report(self):
        self.set_enable_btn = self.ui.z_report.setEnabled
        self.send_data(0, "0")

    def put_cash(self):
        units_input = UnitsInput(Title=_('Service entry'), PlaceholderText=_('Sum'))
        if units_input.exec_() == QDialog.Accepted:
            cash = "%0.2f" % float(units_input.units)
            self.set_enable_btn = self.ui.service_input.setEnabled
            self.send_data(1, cash)

    def take_cash(self):
        units_input = UnitsInput(Title=_('Service output'), PlaceholderText=_('Sum'))
        if units_input.exec_() == QDialog.Accepted:
            cash = "-"+"%0.2f" % float(units_input.units)
            self.set_enable_btn = self.ui.service_output.setEnabled
            self.send_data(1, cash)

    def send_data(self, cmd, data):
        self.ui.progress.setVisible(True)
        self.set_enable_btn(False)
        # self.send_cmd_to_fiscal_printer.emit(cmd, data)

    def processed(self):
        if self.set_enable_btn is not None:
            self.set_enable_btn(True)
        self.ui.progress.setVisible(False)

    def begin_session(self, fio, access):
        return True

    def end_session(self, block=False):
        return True


if __name__ == '__main__':
    import doctest

    doctest.testmod()