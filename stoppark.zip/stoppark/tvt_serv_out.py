import socket
from datetime import datetime, timedelta
import re
import sqlite3
import json

config = {}




def load_config():
    global config
    with open('/usr/local/lib/python2.7/dist-packages/stoppark/config.json', 'r') as file:
        content = file.read()
        config = json.loads(content)
	print("config", config)

def plate_mask(number):
    try:
        number = number.encode("UTF-8")
        print ("if", number[0:1], number[2:])
        if number[0:2] == "UA":
                print("UA")
                number=number[2:]
        if len(re.findall('\d+', number)[0]) == 4 and len(re.findall('\D+', number)[0]) == 2 and len(re.findall('\D+', number)[1]) == 2:
            return number
        else:
            return "--------"
    except:
        return "--------"


def startSubscribe():
    while True:
	print (config)
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect((config['ip_tvt_out'], 8080))
            cmd = "POST /SetSubscribe HTTP/1.1\r\nHost: {0}\r\nAccept-Encoding: gzip, deflate\r\nAccept: */*\r\nConnection: keep-alive\r\nAuthorization: Basic YWRtaW46MTIzNDU2\r\nContent-Type: application/xml\r\nContent-Length: 1078\r\n\r\n<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<config version=\"1.7\" xmlns=\"http://www.ipc.com/ver10\">\r\n<types>\r\n<openAlramObj>\r\n<enum>MOTION</enum>\r\n<enum>SENSOR</enum>\r\n<enum>PEA</enum>\r\n<enum>AVD</enum>\r\n<enum>OSC</enum>\r\n<enum>CPC</enum>\r\n<enum>CDD</enum>\r\n<enum>IPD</enum>\r\n<enum>VFD</enum>\r\n<enum>VFD_MATCH</enum>\r\n<enum>VEHICE</enum>\r\n<enum>AOIENTRY</enum>\r\n<enum>AOILEAVE</enum>\r\n<enum>PASSLINECOUNT</enum>\r\n<enum>TRAFFIC</enum>\r\n</openAlramObj>\r\n<subscribeRelation>\r\n<enum>ALARM</enum>\r\n<enum>FEATURE_RESULT</enum>\r\n<enum>ALARM_FEATURE</enum>\r\n</subscribeRelation>\r\n<subscribeTypes>\r\n<enum>BASE_SUBSCRIBE</enum>\r\n<enum>REALTIME_SUBSCRIBE</enum>\r\n<enum>STREAM_SUBSCRIBE</enum>\r\n</subscribeTypes>\r\n</types>\r\n<channelID type=\"uint32\">0</channelID>\r\n<initTermTime type=\"uint32\">0</initTermTime>\r\n<subscribeFlag type=\"subscribeTypes\">BASE_SUBSCRIBE</subscribeFlag>\r\n<subscribeList type=\"list\" count=\"1\">\r\n<item>\r\n<smartType type=\"openAlramObj\">VEHICE</smartType>\r\n<subscribeRelation type=\"subscribeRelation\">ALARM_FEATURE</subscribeRelation>\r\n</item>\r\n</subscribeList>\r\n</config>\r\n".format(config['ip_tvt_out'])
            client.send(cmd.encode('utf-8'))
            recevied_size = 0
            recevied_data = b''
            fillter = ""
            last_time = datetime.now()
        except Exception:
            print("ERROR")
        client.settimeout(30.0)
        while (datetime.now() - last_time) < timedelta(seconds=30):
            try:
                cmd_res = client.recv(1024)
            except Exception:
                break
            recevied_size += len(cmd_res)
            recevied_data += cmd_res
            word = '''</plateNumber>'''
            if recevied_size > 0:
                src = recevied_data.decode("UTF-8")
                if src.rfind(word) > 0:
                    ind = src.rfind(word)
                    start = src.rfind("[", ind - 40, ind) + 1
                    end = src.find("]", ind - 40, ind)
                    #print(len(src[start:end]))
                    if src[start:end] != "" and src[start:end] != fillter and len(src[start:end]) < 12 and len(
                            plate_mask(src[start:end])) != "--------":
                        fillter = src[start:end]
                        last_time = datetime.now()
                        f1 = open('/mnt/ramdisk/number_out.py', 'w')
                        f1.write(plate_mask(fillter))
                        f1.close()


def get_state():
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    cursor.execute("SELECT cam_ver FROM config_new")
    cam_ver = cursor.fetchone()[0]
    return cam_ver


if __name__ == '__main__':
    f1 = open('/mnt/ramdisk/number_out.py', 'w')
    f1.write("--------")
    f1.close()
    state = get_state()
    print(state)
    if state == 2:
        print("started")
        load_config()
        startSubscribe()
