# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'add_card.ui'
#
# Created: Tue Jan  7 18:34:44 2020
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!
from PyQt4 import QtCore, QtGui
import sys
import add_card1
import login_ci
import sqlite3
from PyQt4.QtSql import *
from gevent import spawn, sleep, get_hub, socket
import datetime
from serial_port import SerialPort
from threading import Thread, Event
from Time import *
import time
import datetime
QtWidgets = QtGui
import math
import mifare_coding

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

def SQL_ID():
	try:
		conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
		cursor = conn.cursor()
		cursor.execute("SELECT ID FROM card")
		results_db = cursor.fetchall()
		results_id = max (results_db)
		Form.ui.lineEdit.setText (str(int(results_id[0])+1))	
		conn.close()
	except:
		Form.ui.lineEdit.setText (str(1))

def CID():
	buff = ''
	Form.ui.lineEdit_3.setText ("")
	Recv()

def Recv():
        buff = ''
        while (buff == ''):
	    sock.send('n')
            sleep(0.1)
            buff += sock.recv(30)
            if buff == "1":
                buff = ''
	    print ("buff : ",buff)
            if (len(buff)) == 16:
                if buff[1] == '0' and buff[2] == '0':
                    after = mifare_coding.main(buff[7:-1])
                    buff = ";00" + after + "?"
                else:
                    after = mifare_coding.main(buff[1:-1])
                    buff = ";00" + after + "?"
        st = buff.index(';') + 1
	end = buff.index('?',st)
	Form.ui.lineEdit_3.setText (str(buff[st:end]))
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
        dec(buff, st, end)
	data_ck = buff[st:end]
	sql = "SELECT ID FROM card WHERE CardID=?"
	cursor.execute(sql, [buff[st:end]])
	results_ck = cursor.fetchall()
	Form.ui.pushButton_4.setEnabled(False)
	Form.ui.label_8.setText('')
	if str(results_ck[0][0]) != '' :
		d = 'Дана картка вже є в базі ID=' + str(results_ck[0][0])
		Form.ui.label_8.setText(_translate("Form", d, None))
		Form.ui.pushButton_4.setEnabled(True)
		Form.ui.pushButton_3.setEnabled(True)
	conn.close()

def dec(buff, st, end):
        bin = "{0:40b}".format(int(buff[st:end], 16))
	f=0
	bino = list(bin)
	for i in range(10):
		z=((i+1)*4)-1
		for k in range(4):
			ind = z-k
			bino[f]= bin[ind]
			f +=1
	for m in range(8):
		bino[m] = 0
	listtostring = ''.join([str(elem) for elem in bino])
        print (listtostring[-24:])
        k = str(int(listtostring[-24:], 2))
	Form.ui.lineEdit_4.setText (k)

def Add_Card():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	conn.text_factory = str
	cursor = conn.cursor()
	ID = Form.ui.lineEdit.text()
	Type = Form.ui.comboBox.currentIndex()
	if len(Form.ui.lineEdit_3.text()) == 8:
		results_cid = "00" + Form.ui.lineEdit_3.text()
	else:
		results_cid = Form.ui.lineEdit_3.text()
	now = datetime.datetime.now()
	DTReg = now.strftime("%y-%m-%d")
	DTEnd = Form.ui.dateEdit.dateTime().toString('yy-MM-dd')
	DrvSn = unicode(Form.ui.lineEdit_2.text()).encode("utf-8")
	gosnom = unicode(Form.ui.lineEdit_5.text()).encode("utf-8")
	data = [str('Card'), int(ID), int(Type), str(results_cid), str(DTReg), str(DTEnd), str('Null'), str('Null'), str('Null'), str('Null'), str(DrvSn), str('Null'), str(gosnom), str('Null'), str('Null'), int('1'), int('0'), int('0'), int('0')]
	cursor.execute('''INSERT INTO card VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', data)
	conn.commit()
	conn.close()
	Form.ui.load()
	SQL_ID()
	sleep(0.5)
	Form.ui.lineEdit_3.setText ('')
	Form.ui.lineEdit_2.setText ('')
	Form.ui.lineEdit_5.setText ('')
	Form.ui.lineEdit_4.setText ('')

class Add_card_gui(QtGui.QWidget):
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)
		self.ui = add_card1.Ui_Form()
		self.ui.setupUi(self)

class login_gui(QtGui.QWidget):
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)
		self.log = login_ci.Login_Form()
		self.log.setupLogin(self)

def Recv_key():
        buff = ""
	z = 0
        while (buff == ''):
	    sock.send('n')
            sleep(0.1)
            buff += sock.recv(80)
            if buff == "1":
                buff = ''
            if (len(buff)) == 16:
                if buff[1] == '0' and buff[2] == '0':
                    after = mifare_coding.main(buff[7:-1])
                    buff = ";00" + after + "?"
                else:
                    after = mifare_coding.main(buff[1:-1])
                    buff = ";00" + after + "?"
	    z += 1
	    print ("z = ",z)
	    if z == 50:
		sys.exit()
	print (buff)
        st = buff.index(';') + 1
	end = buff.index('?',st)
	print(cache)
	if str(buff[st:end]) == cache:
		Form2.hide()
		Form.show()
	else:
		Form2.log.label.setText(_translate("Form", "Невірний майстер ключ", None))

def Delete():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	conn.text_factory = str
	cursor = conn.cursor()
	if Form.ui.lineEdit_3.text() != "":
		if len(Form.ui.lineEdit_3.text()) == 8:
			results_cid = "00" + Form.ui.lineEdit_3.text()
		else:
			results_cid = Form.ui.lineEdit_3.text()
		print ("sql_delete",results_cid)
		cursor.execute('''DELETE FROM card WHERE CardID = ?''', (str(results_cid),))
	else:
		if Form.ui.lineEdit_5.text() != "":
			cursor.execute('''DELETE FROM card WHERE CarGosNom = ?''', (str(unicode(Form.ui.lineEdit_5.text()).encode("utf-8")),))
	Form.ui.lineEdit_3.setText ('')
	Form.ui.lineEdit_2.setText ('')
	Form.ui.lineEdit_5.setText ('')
	Form.ui.lineEdit_4.setText ('')
	Form.ui.label_8.setText('')
	Form.ui.pushButton_4.setEnabled(False)
	conn.commit()
	conn.close()
	Form.ui.load()

def MOD():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	conn.text_factory = str
	cursor = conn.cursor()
	if Form.ui.lineEdit_2.text() != "":
		cursor.execute('''UPDATE card SET DriveFam = ? WHERE CardID = ?''', (str(unicode(Form.ui.lineEdit_2.text()).encode("utf-8")),str(unicode(Form.ui.lineEdit_3.text()).encode("utf-8"))))
	if Form.ui.lineEdit_5.text() != "":
		cursor.execute('''UPDATE card SET CarGosNom = ? WHERE CardID = ?''', (str(unicode(Form.ui.lineEdit_5.text()).encode("utf-8")),str(unicode(Form.ui.lineEdit_3.text()).encode("utf-8")))) 
	Form.ui.lineEdit_3.setText ('')
	Form.ui.lineEdit_2.setText ('')
	Form.ui.lineEdit_5.setText ('')
	Form.ui.lineEdit_4.setText ('')
	Form.ui.label_8.setText('')
	conn.commit()
	conn.close()
	Form.ui.load()
	Form.ui.pushButton_4.setEnabled(False)

if __name__ == "__main__":
	app = QtGui.QApplication(sys.argv)
	Form = Add_card_gui()
	Form2 = login_gui()
	Form2.show()
        sock = SerialPort('/dev/ttyS4', 9600)
	Form2.log.pushButton3.clicked.connect(Recv_key)
	SQL_ID()
	Form.ui.load()
	Form.ui.pushButton.clicked.connect(Add_Card)
	Form.ui.pushButton_2.clicked.connect(CID)
	Form.ui.pushButton_3.clicked.connect(Delete)
	Form.ui.pushButton_4.clicked.connect(MOD)
	sys.exit(app.exec_())


