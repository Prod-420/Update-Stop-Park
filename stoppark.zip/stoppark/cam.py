import os
import sys
import datetime
import sqlite3
from card import Card

bar_fillter = ""

def get_state():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        cursor = conn.cursor()
        cursor.execute("SELECT cam_ver FROM config_new")
	cam_ver = cursor.fetchone()[0]
	return cam_ver
	

def get_number_in():
	f = open("/mnt/ramdisk/number_in.py", 'r')
	number = f.read ()
	f.close
	return number

def get_check_card_in():
	number = get_number_in()
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	sql = 'SELECT DTEnd, Status FROM Card WHERE CarGosNom == "{}" '.format(str(number))
	cursor.execute(sql)
	results = cursor.fetchall()
	now = datetime.datetime.now().strftime("%y-%m-%d")
	conn.close()
	try:
		if results[0][0].encode("ascii") > now and (results[0][1] == 5 or results[0][1] == 1):
			return True
		else:
			return False
	except:
		return False

def get_ticket_number():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	sql = "select bar from Ticket where ID = (select max(ID) from Ticket)"
	cursor.execute(sql)
	bar = cursor.fetchone()[0].encode("UTF-8")
	print (bar, "get_ticket_number")
	return bar

def mod_db():
	f = open("/mnt/ramdisk/number_in.py", 'r')
	number = f.read ()
	f.close
	conn = sqlite3.connect('/home/olimex/.stoppark/db')
	cursor = conn.cursor()
	sql = 'UPDATE config SET UserStr8 = "{}"'.format(str(number))
	cursor.execute(sql)
	conn.commit()
	conn.close()

def get_number_out():
	f = open("/mnt/ramdisk/number_out.py", 'r')
	number = f.read ()
	f.close
	return number

def get_check_card_out():
	number = get_number_out()
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	sql = 'SELECT DTEnd, Status FROM Card WHERE CarGosNom == "{}" '.format(str(number))
	cursor.execute(sql)
	results = cursor.fetchall()
	now = datetime.datetime.now().strftime("%y-%m-%d")
	conn.close()
	try:
		if results[0][0].encode("ascii") > now and (results[0][1] == 6 or results[0][1] == 1):
			return True
		else:
			return False
	except:
		return False

def get_update_number_in():
	f = open("/mnt/ramdisk/number_in.py", 'r')
	number = f.read ()
	f.close
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	ID = SQL_ID()
	if number != '':
		sql = 'UPDATE events SET GosNom = "{}" WHERE id = "{}" '.format(str(number),ID[0])
		cursor.execute(sql)
		conn.commit()
	conn.close()

def get_update_number_out():
	f = open("/mnt/ramdisk/number_out.py", 'r')
	number = f.read ()
	f.close
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	ID = SQL_ID()
	if number != '':
		sql = 'UPDATE events SET GosNom = "{}" WHERE id = "{}" '.format(str(number),ID[0])
		cursor.execute(sql)
		conn.commit()
	conn.close()

def SQL_ID():
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	cursor.execute("SELECT id FROM events")
	results_db = cursor.fetchall()
	results_id = max (results_db)	
	conn.close()
	return results_id

def Number_clear(adrr):
	if adrr % 2 == 0:
		f = open("/mnt/ramdisk/number_in.py", 'w')
		number = f.write('--------')
		f.close
                print("Write -------- Number_clear")
		conn = sqlite3.connect('/home/olimex/.stoppark/db')
		cursor = conn.cursor()
		sql = 'UPDATE config SET UserStr8 = "{}"'.format('--------')
		cursor.execute(sql)
		conn.commit()
		conn.close()
	if adrr % 2 == 1:
		f = open("/mnt/ramdisk/number_out.py", 'w')
		number = f.write('--------')
		f.close
                print("Write -------- Number_clear")
	

def Clear_once(trig):
	if trig == 0:
		conn = sqlite3.connect('/home/olimex/.stoppark/db')
		cursor = conn.cursor()
		sql = 'UPDATE config SET UserStr8 = "{}"'.format('--------')
		cursor.execute(sql)
		conn.commit()
		conn.close()
		trig = 1
                return trig
        else:
            if trig == 1:
                path = "/mnt/ramdisk/number_in.py"
            if trig == 2:
                path = "/mnt/ramdisk/number_out.py"
            f1 = open(path, 'w')
            f1.write('--------')
            f1.close
            print("Write -------- Clear_once")


def Get_card_id(terminal_id):
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
        sql_number = 'SELECT GosNom FROM Events WHERE Terminal == {}'.format(int(terminal_id))
	cursor.execute(sql_number)
	results_number = cursor.fetchall()
	number = results_number[-1][0].encode("ascii")
	sql = 'SELECT CardID FROM Card WHERE CarGosNom == "{}" '.format(str(number))
	cursor.execute(sql)
	results = cursor.fetchone()
	conn.close()
	try:
		return results[0].encode("ascii"), number
	except:
		print ("NO DATA")

def Status_APB():
	conn_apb = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor_apb = conn_apb.cursor()
	sql_apb = 'SELECT APB FROM config_new'
	cursor_apb.execute(sql_apb)
	status = cursor_apb.fetchone()
	conn_apb.close()
	return status[0]

def Change_status_in(number):
	status = Status_APB()
	if status == 1:
		status_db = 6
	else:
		status_db = 1
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	sql = 'UPDATE card SET Status = "{}" WHERE CarGosNom = "{}" '.format(str(status_db), str(number))
	cursor.execute(sql)
	conn.commit()
	conn.close()

def Change_status_out(number):
	status = Status_APB()
	if status == 1:
		status_db = 5
	else:
		status_db = 1
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	sql = 'UPDATE card SET Status = "{}" WHERE CarGosNom = "{}" '.format(str(status_db), str(number))
	cursor.execute(sql)
	conn.commit()
	conn.close()

def reg_bar_nom(bar):
    f = open("/mnt/ramdisk/number_in.py", 'r')
    number = f.read ()
    f.close
    if number != "--------":
        conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        cursor = conn.cursor()
        sql = 'INSERT INTO Bar_Nom VALUES("{0}", "{1}", "{2}")'.format(str(bar), str(number), int(1))
        cursor.execute(sql)
        conn.commit()
        conn.close()

def get_bar():
    f = open("/mnt/ramdisk/number_out.py", 'r')
    number = f.read ()
    f.close
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    sql_number = 'SELECT bar FROM Bar_Nom WHERE number == "{}"'.format(str(number))
    cursor.execute(sql_number)
    results_number = cursor.fetchone()
    conn.close()
    try:
            return results_number[0].encode("ascii")
    except:
            print ("NO DATA")


def bar_out(bar):
    print ("Bar_out", datetime.datetime.now().strftime('%y-%m-%d %H:%M:%S'))
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    sql = 'UPDATE Ticket SET Status = "{}", TimeOut = "{}" WHERE BAR = "{}" '.format(str(15), datetime.datetime.now().strftime('%y-%m-%d %H:%M:%S'), str(bar))
    cursor.execute(sql)
    conn.commit()
    conn.close()
    bar_delete(bar)

def bar_delete(bar):
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    sql_number = 'DELETE FROM Bar_Nom WHERE bar == "{}"'.format(str(bar))
    cursor.execute(sql_number)
    conn.commit()
    conn.close()


def ticket_paid():
    conn2 = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor2 = conn2.cursor()
    sql = 'SELECT * FROM config_new'
    cursor2.execute(sql)
    pars = cursor2.fetchone()
    free_time = pars[4]
    paid_time = pars[8]
    print (free_time, paid_time)
    result = [0]
    bar = get_bar()
    global bar_fillter
    print ("bar_fillter", bar_fillter, bar)
    if bar_fillter != bar:
        conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        cursor = conn.cursor()
        sql_status = 'SELECT Status, TimeCount, TimeDopl, TimeIn FROM Ticket WHERE BAR == {}'.format(str(bar))
        if bar == None:
            return False
        cursor.execute(sql_status)
        result = cursor.fetchone()
        bar_fillter = bar
        if result == None:
            return False
        else:
            DTPaid, DTDopPaid, DTIn =conver_data(result)
            print("status_bar", DTPaid, DTDopPaid, DTIn)
            print ((datetime.datetime.now() - DTIn).seconds/60)
            if (datetime.datetime.now() - DTIn).seconds/60 < free_time:
                return True
            else:
                if result[0] == 5 and (((datetime.datetime.now() - DTPaid).seconds/60 < paid_time) or ((datetime.datetime.now() - DTDopPaid).seconds/60 < paid_time)):
                    return True
                else:
                    return False
    else:
        return False

def conver_data(result):
    if result[1] != None : DTPaid = datetime.datetime.strptime(result[1].decode("UTF-8"), '%y-%m-%d %H:%M:%S')
    else: DTPaid = None
    if result[2] != None : DTDopPaid = datetime.datetime.strptime(result[2].decode("UTF-8"), '%y-%m-%d %H:%M:%S')
    else: DTDopPaid = None
    if result[3] != None : DTIn = datetime.datetime.strptime(result[3].decode("UTF-8"), '%y-%m-%d %H:%M:%S')
    else: DTIn = None
    return DTPaid, DTDopPaid, DTIn


def check_telegram():
    number = get_number_in()
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    sql_number = 'SELECT bar FROM Telegram WHERE number == "{}"'.format(str(number))
    cursor.execute(sql_number)
    results_number = cursor.fetchone()
    conn.close()
    print (results_number)
    if results_number != None:
         return True
    return False

def insert_ticket(number):
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    sql_number = 'SELECT bar FROM Telegram WHERE number == "{}"'.format(str(number))
    cursor.execute(sql_number)
    results_number = cursor.fetchone()
    conn.close()
    return results_number[0].encode("UTF-8")
