import os
import cgi
import sys
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from i18n import language
from gevent import sleep, spawn
from gevent.queue import Queue
from u2py.interface_basis import load, BaseReader as Terminal, DumpableStructure, DumpableBigEndianStructure, ByteArray
from u2py.interface import ReaderError
from ctypes import POINTER as P, c_uint16, c_uint8, c_char, c_char_p, Structure


class customHTTPServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write('<HTML><body>GO AWAY</body></HTML>')
        return

    def do_POST(self):
        global rootnode
	args = {}
        ctype, pdict = cgi.parse_header(self.headers.getheader('Content-type'))
        if ctype == 'multipart/form-data':
            query = cgi.parse_multipart(self.rfile, pdict)
            self.Change(query)
	    #print (query)
        self.send_response(301)
        self.end_headers()
        self.wfile.write('Post!')

    def Change(self, query):
            first = query['event']
            second = first[0]
            ind = second.find('plateASCII')
            indplate = second.find(':', ind)
            indplate2 = second.find('"', indplate + 3)
	    print (second[indplate+2:indplate2])
	    f1 = open ('/mnt/ramdisk/number_out.py', 'w')
	    f1.write (second[indplate+2:indplate2])
	    f1.close()

def get_state():
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    cursor.execute("SELECT cam_ver FROM config_new")
    cam_ver = cursor.fetchone()[0]
    return cam_ver




def main():
    f1 = open ('/mnt/ramdisk/number_out.py', 'w')
    f1.write ("--------")
    f1.close()
    if get_state() == 1:
        try:
            server = HTTPServer(('0.0.0.0', 7366), customHTTPServer)
            print('server started at port 7360')
            server.serve_forever()
        except KeyboardInterrupt:
            server.socket.close()


if __name__ == '__main__':
    main()
