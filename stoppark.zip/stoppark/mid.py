from asyncore import dispatcher, dispatcher_with_send, loop
from socket import AF_INET, SOCK_STREAM
from database import Model
from datetime import datetime
from os import path, remove
import time
import logging
import logging.config
import re
from subprocess import Popen
from sqlite3 import connect as sqlite3_connect
from sqlitebck import copy as sqlitebck_copy
from threading import Thread, Event
from shutil import make_archive

LOCAL_DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'

# ADDR = getoutput("/sbin/ifconfig").split("\n")[1].split()[1][5:] , 101

logging.config.dictConfig({
 'version': 1,    # Configuration schema in use; must be 1 for now
 'formatters': {
     'standard': {
         'format': ('%(asctime)s %(host)-15s '
                    '%(levelname)-8s %(message)s')}},

 'handlers': {'mid': {'backupCount': 10,
                      'class': 'logging.handlers.RotatingFileHandler',
                      'filename': 'data/mid.log',
                      'formatter': 'standard',
                      'level': 'DEBUG',
                      'maxBytes': 10000000}
              },
 # Specify properties of the root logger
 'root': {
          'level': 'DEBUG',
          'handlers': ['mid']
 },
})


def synch_time(comm):
    import sys

    max_date = datetime.strptime('2023-02-01 00:00:01', LOCAL_DATETIME_FORMAT)
    min_date = datetime.strptime('2013-01-01 00:00:01', LOCAL_DATETIME_FORMAT)

    # print 'comm ', comm
    match = re.search(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', comm)
    if match:
        # print 'match ', match.group()
        dt1 = datetime.strptime(match.group(), LOCAL_DATETIME_FORMAT)
        if datetime.now() < min_date or datetime.now() > max_date:
            arg = dt1.strftime('%m%d%H%M%Y.%S')
            # print 'arg ', arg
            if sys.platform == 'linux2':
                Popen(['date', arg])
                time.sleep(3)

    return datetime.now().strftime(LOCAL_DATETIME_FORMAT)


class TcpServer(dispatcher):
    def __init__(self, (host, port), handler):
        dispatcher.__init__(self)
        self.handler = handler
        self.create_socket(AF_INET, SOCK_STREAM)
        self.set_reuse_addr()
        self.bind((host, port))
        self.listen(20)
        print 'Listen on %s:%s' % (host, port)

    def handle_accept(self):
        pair = self.accept()
        if pair:
            self.handler(pair)


class Handler(dispatcher_with_send):

    BYTES_TO_RECV = 512
    COMMAND_PREFIX = '>>>'
    backupEvent = Event()

    COMMAND_HANDLERS = {
       'reset': lambda: Model.connection.open(replace=True),
       'disconnect': lambda: Model.connection.close(),
       'reboot': lambda: Popen(['reboot']),
       # 'get_time': lambda: synch_time(),
       'set_time': lambda: None
    }

    def __init__(self, (sock, (host, port))):
        dispatcher_with_send.__init__(self, sock)
        self.extra = {'host': host}
        self.databaseFilename = 'data/db.db3'
        self.databaseBackup = 'data/backup/server.db3'

    def backup_database(self, database_filename, database_backup):
        self.backupEvent.set()
        if path.exists(database_backup):
            remove(database_backup)
        connect_db = sqlite3_connect(database_filename)
        connect_db_backup = sqlite3_connect(database_backup)
        sqlitebck_copy(connect_db, connect_db_backup)
        connect_db.close()
        connect_db_backup.close()
        time.sleep(1)
        make_archive("data/backup", 'zip', "data/backup")
        self.backupEvent.clear()
        print 'backup created'
        logging.debug("<-[%s]", 'backup_base', extra=self.extra)

    def handle_command(self, command):
        # print 'handle_command', command
        res = 'OK'
        if command[:9] == 'get_time:':
            res = synch_time(comm=command)
            self.send(res)
            logging.debug("<-[%s]", res or 'NONE', extra=self.extra)
        elif command[:12] == 'backup_base:':
            print(self.backupEvent.is_set())
            if not self.backupEvent.is_set():
                self.send('Start backup process')
                Thread(name='backup_loop', target=self.backup_database, args=(self.databaseFilename,
                                                                              self.databaseBackup, )).start()
            else:
                self.send('backup processing')
        elif command[:13] == 'backup_status':
            if not self.backupEvent.is_set():
                self.send('Backup created')
            else:
                self.send('backup processing')
        else:
            try:
                self.COMMAND_HANDLERS[command]()
                self.send(res)
                logging.debug("<-[%s]", res or 'NONE', extra=self.extra)
            except Exception as ex:
                logging.error('%s[%s]', ex.__class__.__name__, ex, extra=self.extra)
                self.send('FAIL')

    def handle_query(self, query):
        try_count = 3
        for i in range(try_count):
            try:
                rows = Model.connection.cursor().execute(query)
                answer = '\n'.join('|'.join(str(field) for field in row) for row in rows)
                logging.debug("<-[%s]", answer or 'NONE', extra=self.extra)
                self.sendall(answer) if answer else self.send('NONE')
                # Model.connection.commit()
                break
            except Exception as ex:
                logging.error('%s[%s]', ex.__class__.__name__, ex, extra=self.extra)
                self.send('FAIL')
                time.sleep(.300)

    def handle_read(self):
        query = self.recv(self.BYTES_TO_RECV)
        if query:
            logging.debug('->[%s]', query, extra=self.extra)
            if query.startswith(self.COMMAND_PREFIX):
                self.handle_command(query[3:])
            else:
                self.handle_query(query)
        self.close()

sql = TcpServer(('0.0.0.0', 101), Handler)
loop()
