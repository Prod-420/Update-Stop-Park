#!/bin/bash

/sbin/reboot

