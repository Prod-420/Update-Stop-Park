#!/bin/bash
#
# SCRIPT: Update_stoppark
# AUTHOR: DmitryK
# DATE: 16.02.2016
# REV: 1.3 
#
# PLATFORM: (Debian 7 ARM OLinuXino-A20-micro)
#
# PURPOSE: Copy and install updates stored in root directory from usb flash drive .
#
# REV LIST:
#        DATE: 23.05.2016
#        BY: DmitryK
#        MODIFICATION: Check update.tar on usb flash. 

##########################################################
#DEFINE FILES AND VARIABLES HERE
##########################################################

export LOG=/home/olimex/update.log
date >> $LOG
export HOMEPATH=/home/olimex/

##########################################################
#BEGINNING OF MAIN
##########################################################

#Find mount point for the last connected usb drive
#start
start_pattern="/media"
end_pattern="type"
stringX=$(mount|tail -n1)  2>> $LOG
start_index=$(awk -v mystring="$stringX" -v serach_pattern="$start_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
end_index=$(awk -v mystring="$stringX" -v serach_pattern="$end_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
export DISKPATH=${stringX:$start_index-1:$end_index-($start_index+1)} 2>> $LOG
#end
if [ -f $DISKPATH/update.tar ]; then
  mkdir $HOMEPATH/$(date +%F) 2>> $LOG; tar -xvf $DISKPATH/update.tar -C $HOMEPATH/$(date +%F) 2>> $LOG && /usr/local/lib/python2.7/dist-packages/stoppark/update_install; mv $HOMEPATH/$(date +%F) /tmp/update_$(date +%F_%H.%M.%S) 2>> $LOG; echo "Оновлення завершено" >> $LOG; leafpad $LOG
else
  echo "Файл оновлення не знайдено, перевірте usb носій." >> $LOG
  echo $DISKPATH >> $LOG
  leafpad $LOG
fi

# End of script

