#!/bin/bash

source /usr/local/lib/python2.7/dist-packages/stoppark/bash_scripts/server_ip.conf

COUNT=4

export DISPLAY=:0

for myHost in $HOSTS
do
  count=$(ping -c $COUNT $myHost | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
  if [ $count -eq 0 ]; then
    # 100% failed 
    echo "Error ping $myHost $(date)" >> /tmp/ping.log
    /usr/bin/notify-send "Сервер: $myHost недоступний (перевiрте локальну мережу)"
    sleep 3
  fi
done

