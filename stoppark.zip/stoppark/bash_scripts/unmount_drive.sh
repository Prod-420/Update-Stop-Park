#!/bin/bash
#
# SCRIPT: save_logs
# AUTHOR: DmitryK
# DATE: 23.05.2016
# REV: 1.0 
#
# PLATFORM: (Debian 7 ARM OLinuXino-A20-micro)
#
# PURPOSE: Unmount USB Flash Drive.
#
# REV LIST:
#        DATE: 
#        BY: 
#        MODIFICATION:    

##########################################################
#DEFINE FILES AND VARIABLES HERE
##########################################################

export LOG=/home/olimex/umount.log
date >> $LOG
export HOMEPATH=/home/olimex/

##########################################################
#BEGINNING OF MAIN
##########################################################

#Find mount point for the last connected usb drive
#start
start_pattern="/media"
end_pattern="type"
stringX=$(mount|tail -n1)  2>> $LOG
start_index=$(awk -v mystring="$stringX" -v serach_pattern="$start_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
end_index=$(awk -v mystring="$stringX" -v serach_pattern="$end_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
export DISKPATH=${stringX:$start_index-1:$end_index-($start_index+1)} 2>> $LOG
#end

#Find last drive in mount list
#start
end_pattern=" on /media"
stringX=$(mount|tail -n1)  2>> $LOG
end_index=$(awk -v mystring="$stringX" -v serach_pattern="$end_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
if [ "$end_index" -eq "0" ]; then
  MOUNTPATH=None
else
  MOUNTPATH=${stringX:0:$end_index-1} 2>> $LOG
  echo $MOUNTPATH > $LOG;
#end
fi

if [ -f $DISKPATH/script.bin ]; then
  echo "Помилка umount: відсутній usb носій." > $LOG
  leafpad $LOG
else
  if [ "$end_index" -eq "0" ]; then
    echo "Помилка umount: відсутній usb носій." > $LOG; leafpad $LOG
  else 
    umount $MOUNTPATH; echo "Пристрій USB можна виймати" >> $LOG; leafpad $LOG
  fi
fi

# End of script

