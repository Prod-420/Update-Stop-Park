# Maual update time from Stoppark server 
# get server ip from file /usr/local/lib/python2.7/dist-packages/stoppark/bash_scripts/server_ip.conf
# For autostart put path to this script in the file /etc/rc.local

#!/bin/bash

sleep 120

date >> /var/log/syslog
HOSTS="$(cut -c 8-17 /usr/local/lib/python2.7/dist-packages/stoppark/bash_scripts/server_ip.conf)"

rdate -4 -n $HOSTS >> /var/log/syslog
