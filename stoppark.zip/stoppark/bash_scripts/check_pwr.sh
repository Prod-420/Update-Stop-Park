#!/bin/bash 

AC_STATUS=-1
function get_status {
	#read Power status register @00h
	POWER_STATUS=$(i2cget -y -f 0 0x34 0x00)
	echo $POWER_STATUS

	# bit 7 : Indicates ACIN presence 0: ACIN does not exist; 1: ACIN present
	#echo � bit 7 : Indicates ACIN presence 0: ACIN does not exist; 1: ACIN present �
	#echo � bit 2 : Indicates that the battery current direction 0: battery discharge; 1: The battery is charged �

	AC_STATUS=$(($(($POWER_STATUS&0x80))/128))  # divide by 128 is like shifting rigth 8 times
	echo $(($POWER_STATUS&0x80))
	echo " AC_STATUS= "$AC_STATUS
        echo $AC_STATUS
        sleep 2
}

function absent {
	local COUNTER=0
	while [  $COUNTER -lt 3 ]; do
		echo The counter is $COUNTER
		logger "The counter is $COUNTER"
        	let COUNTER+=1
		get_status
		if [ $AC_STATUS = 1 ]; then
			echo power is Ok now $AC_STATUS
			logger "power is Ok now $AC_STATUS"
			return 0
		else
			echo no power supply yet $AC_STATUS
			logger "no power supply yet $AC_STATUS"
			#continue
		fi
		sleep 10
	done
	if [ $AC_STATUS = 0 ]; then
		/bin/sync
		/sbin/shutdown -h now "no power supply"
	fi
}

while true 
do
	get_status
	if [ $AC_STATUS = 1 ]; then
		echo power is Ok $AC_STATUS
		continue
	else
		echo no power supply $AC_STATUS
		logger "no power supply $AC_STATUS"
		absent
	fi
	sleep 10
done

exit 0
