#!/bin/bash
#
# SCRIPT: save_logs
# AUTHOR: DmitryK
# DATE: 13.05.2016
# REV: 1.1 
#
# PLATFORM: (Debian 7 ARM OLinuXino-A20-micro)
#
# PURPOSE: Copy logs on usb flash drive.
#
# REV LIST:
#        DATE: 23.05.2016
#        BY: DmitryK
#        MODIFICATION: Check USB Flash Drive.   

##########################################################
#DEFINE FILES AND VARIABLES HERE
##########################################################

export LOG=/home/olimex/save_logs.log
date >> $LOG
export HOMEPATH=/home/olimex/

##########################################################
#BEGINNING OF MAIN
##########################################################
#Find mount point for the last connected usb drive
#start
start_pattern="/media"
end_pattern="type"
stringX=$(mount|tail -n1)  2>> $LOG
start_index=$(awk -v mystring="$stringX" -v serach_pattern="$start_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
end_index=$(awk -v mystring="$stringX" -v serach_pattern="$end_pattern" 'BEGIN{print index(mystring,serach_pattern)}')  2>> $LOG
export DISKPATH=${stringX:$start_index-1:$end_index-($start_index+1)} 2>> $LOG
#end
if [ -f $DISKPATH/script.bin ]; then
  echo "Помилка: usb носій відсутній" >> $LOG
  echo $DISKPATH >> $LOG
  leafpad $LOG
else
  if touch $DISKPATH/stoppark.txt 2>> $LOG; then
    tar -cvf $HOMEPATH/stoppark_logs.tar /home/olimex/.stoppark/log* 2>> $LOG || tar -cvf $HOMEPATH/stoppark_logs.tar $DISKPATH/stoppark.txt; tar --append --file=$HOMEPATH/stoppark_logs.tar /home/olimex/stoppark/data/mid* 2>> $LOG; tar --append --file=$HOMEPATH/stoppark_logs.tar /home/olimex/update.log 2>> $LOG; tar --append --file=$HOMEPATH/stoppark_logs.tar /var/log/syslog 2>> $LOG; tar --append --file=$HOMEPATH/stoppark_logs.tar /var/log/syslog.1 2>> $LOG; tar -czvf $DISKPATH/stoppark_logs.tar.gz $HOMEPATH/stoppark_logs.tar; rm $HOMEPATH/stoppark_logs.tar 2>> $LOG; rm $DISKPATH/stoppark.txt 2>> $LOG; echo "Журнали збережені в корінному каталозі на usb, файл stoppark_logs.tar" >> $LOG; leafpad $LOG
  else
    echo "Помилка запису на usb носій" >> $LOG
    leafpad $LOG
  fi
fi
