def get_cost(t1,t2):
    from datetime import datetime, timedelta
    from BusinessHours import BusinessHours
    import time
    import sqlite3
    conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
    cursor = conn.cursor()
    cursor.execute("SELECT work_start FROM config_new")
    work_time_start = cursor.fetchone()
    cursor.execute("SELECT work_end FROM config_new")
    work_time_end = cursor.fetchone()
    cursor.execute("SELECT cost_night FROM config_new")
    cost_night = int(cursor.fetchone()[0])
    cursor.execute("SELECT cost_weekend FROM config_new")
    cost_weekend = int(cursor.fetchone()[0])
    cursor.execute("SELECT FREE_TIME FROM config_new")
    Free_time = int(cursor.fetchone()[0])
    cursor.execute("SELECT cost_hour FROM config_new")
    cost_day = int(cursor.fetchone()[0])
    conn.close()
    date = "2020-01-01 "
    work_start_int = str(work_time_start[0])
    work_end_int = str(work_time_end[0])				#format time when end work day
    work_start = datetime.strptime(date+work_start_int, "%Y-%m-%d %H")  #format time when start work day
    work_end = datetime.strptime(date+work_end_int, "%Y-%m-%d %H")      #format time when end work day
    enter = t1                                  #format in time
    exit = t2                                   #format out time
    d1_ts = time.mktime(enter.timetuple())                      #format hours for get full parking time
    d2_ts = time.mktime(exit.timetuple())                       #format hours for get full parking time
    d3_ts = time.mktime(work_start.timetuple())                 #format hours for get full working time
    d4_ts = time.mktime(work_end.timetuple())                   #format hours for get full working time
    res = BusinessHours(enter, exit, worktiming=[int(work_start_int), int(work_end_int)], weekends=[6,7]).getminutes()            #get minuts from work time
    if res % 60 != 0:                                           #calc hours from minuts from work time
        hours = (res / 60) +1
    else:
        hours = res / 60
    full_parking_minutes = int(d2_ts-d1_ts) / 60                        #calc full minutes
    full_working_minutes = int(d4_ts-d3_ts) / 60                        #calc full minutes
    night_minutes = 1440 - full_working_minutes                         #calc full minutes for night time
    date_check = datetime.strptime(enter.strftime("%Y-%m-%d"),"%Y-%m-%d")
    weekends = 0
    full_weekends = 0
    night_num = 0
    if enter.isoweekday() == 6 or enter.isoweekday() == 7:
	if enter.strftime("%H:%M")< "23:59":
	    full_weekends -= 1
	    enter_buff = datetime.strptime("23:59", '%H:%M') - datetime.strptime(enter.strftime("%H:%m"), '%H:%M')
	    enter_buff = enter_buff.total_seconds() /60
    else:
	enter_buff = 0
    if exit.isoweekday() == 6 or exit.isoweekday() == 7:
	if exit.strftime("%H:%M") > "00:00":
	    full_weekends -= 1
	    exit_buff = datetime.strptime(exit.strftime("%H:%M"), '%H:%M') - datetime.strptime("00:00", '%H:%M')
	    exit_buff = exit_buff.total_seconds() /60
    else:
	exit_buff = 0
    while date_check <= exit:
	if date_check.isoweekday() == 6 or date_check.isoweekday() == 7:
	    weekends += 1
	    full_weekends += 1
	date_check = date_check + timedelta(days = 1)
    if full_weekends < 0:
	full_weekends = 0
    full_parking_minutes = full_parking_minutes - (1440 * full_weekends) - enter_buff - exit_buff
    if ((full_parking_minutes - res) % night_minutes) != 0:             #calc numbers of night tarifs for car
        night_num = ((full_parking_minutes - res) // night_minutes) +1
    else:
        night_num = ((full_parking_minutes - res) // night_minutes)
    if (enter.strftime("%d/%m/%y") == exit.strftime("%d/%m/%y")):       #check if car go to park after midnight and leave before
            if ((int(work_end_int)) - int(enter.strftime("%H"))) > full_working_minutes // 60:
                night_num+=1
    if full_parking_minutes == res:
        cost = hours * cost_day                                         #calc cost without night tariff
    else:
        cost = (hours * cost_day) + (cost_night * night_num)            #calc cost with night tariff
    if cost < 0:
	cost = 0
    cost = cost + (weekends * cost_weekend)
    if (int(d2_ts-d1_ts) / 60) < Free_time:
	cost = 0
    return cost
