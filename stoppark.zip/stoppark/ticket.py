# coding=utf-8
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import QObject, pyqtProperty, pyqtSlot
from datetime import datetime, timedelta
from config import DATETIME_FORMAT, DATETIME_FORMAT_FULL, DATETIME_FORMAT_USER
from tariff import Tariff
from payment import Payment
from i18n import language
import socket
import re
import sqlite3
import coding
import db
import cam
_ = language.ugettext
_n = language.ungettext

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class BaseTicketPayment(Payment):
    def __init__(self, ticket, tariff):
        Payment.__init__(self, ticket.payments)

        self._enabled = hasattr(tariff, 'calc')
        if not self._enabled:
            return

        self.ticket = ticket
        self.tariff = tariff
        self.now = datetime.now()

    @pyqtProperty(bool, constant=True)
    def enabled(self):
        return self._enabled

    @pyqtProperty(int, constant=True)
    def price(self):
        return self.result.price

    @property
    def check_interval(self):
        return {
            Tariff.HOURLY: _n('hour_', 'hours_', 1),
            Tariff.DAILY: _n('day_', 'days_', 1),
            Tariff.MONTHLY: _n('month_', 'months_', 1)
        }[self.tariff.interval]

    @property
    def db_payment_args(self):
        return {
            'payment': 'Talon payment',
            'tariff': self.tariff.id,
            'id': self.ticket.bar,
            'cost': self.result.cost,
            'units': self.result.units,
            'begin': self.ticket.time_in.strftime(DATETIME_FORMAT_FULL),
            'end': self.now.strftime(DATETIME_FORMAT_FULL),
            'price': self.result.price
        }


class TicketPayment(BaseTicketPayment):

    def get_free_time(self):
        try:
            conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	    cursor = conn.cursor()
	    cursor.execute("select FREE_TIME from config_new")
	    results_db = cursor.fetchall()
	    result = results_db [0][0]	
	    conn.close()
            return int(result)
        except (ValueError, KeyError):
            print 'LocalDB_get_free_time_err_log'
            return None

    def __init__(self, ticket, tariff):
        BaseTicketPayment.__init__(self, ticket, tariff)

        if self._enabled:
	    time_in2 = self.ticket.time_in + timedelta(minutes = self.get_free_time())
            self.result = tariff.calc(time_in2, self.now)

    @property
    def paid_until(self):
        return self.now

    @pyqtProperty(str, constant=True)
    def explanation(self):
        if not self._enabled:
            return _('Ticket %s.\n'
                     'Not payable with this tariff.') % (self.ticket.bar,)
        return _('Payment for ticket %(bar)s.\n'
                 'Time in: %(time_in)s.\n'
                 '%(details)s') % {
                     'bar': self.ticket.bar,
                     'time_in': self.ticket.time_in.strftime(DATETIME_FORMAT_USER) + _translate("Form", '         Безкоштовний період: ', None)+ str(self.get_free_time()) + _translate("Form", 'хв', None),
                     'details': self.result
                 }

    def vfcd_explanation(self):
        return [
            self.tariff.cost_info,
            self.price_info
        ]

    TICKET_QUERY = ('update ticket set typetarif=%i, pricetarif="%s", summ=%i * 100,\
                    summdopl=0, TimeCount="%s", status = status | %i where bar="%s"')

    def execute(self, db):
        ticket_args = (self.tariff.id, self.tariff.cost_db, self.result.price,
                       self.paid_until.strftime(DATETIME_FORMAT), Ticket.PAID, self.ticket.bar)
        ret = db.query(self.TICKET_QUERY % ticket_args) is None
        if not ret:
            return ret
        if db.local.option("enableExcess") == "0":
            self.ticket.out(db)             #  The ticket status sets out after pay to disable the TicketExcessPayment
        return db.generate_payment(self.db_payment_args)

    def check(self, db):
        args = {
            'time_in': self.ticket.time_in.strftime(DATETIME_FORMAT_USER),
            'now': self.now.strftime(DATETIME_FORMAT_USER),
            'cost_info': self.tariff.cost_info_check,
            'duration': self.result.check_duration,
            'paid_until': self.paid_until.strftime(DATETIME_FORMAT_USER),
            'price': self.price,
            'bar': self.ticket.bar
        }

        return (Payment.check(self, db) + _('  entry time: %(time_in)s\n'
                                            'payment time: %(now)s\n'
                                            '      tariff: %(cost_info)s\n'
                                            'parking duration: %(duration)s\n'
                                            '  paid until: %(paid_until)s\n'
                                            '<hr />\n'
                                            'Price: $%(price)s\n'
                                            '<hr />\n'
                                            '<<%(bar)s>>') % args)


class TicketExcessPayment(BaseTicketPayment):
    def __init__(self, ticket, tariff, excess=False):
        BaseTicketPayment.__init__(self, ticket, tariff)

        if self._enabled:
            self.excess = excess
            self.base_time = self.ticket.time_excess_paid if self.excess else self.ticket.time_paid
            self.result = tariff.calc(self.base_time, self.now)

    @property
    def paid_until(self):
        return self.base_time + self.result.paid_time

    @pyqtProperty(str, constant=True)
    def explanation(self):
        if not self._enabled:
            return _('Ticket %s.\n'
                     'Not payable with this tariff.') % (self.ticket.bar,)
        return _('Extra payment for ticket: %(bar)s.\n'
                 'Time in: %(time_in)s.\n'
                 'Last payment: %(base_time)s.\n'
                 '%(details)s') % {
                     'bar': self.ticket.bar,
                     'time_in': self.ticket.time_in.strftime(DATETIME_FORMAT_USER),
                     'base_time': self.base_time.strftime(DATETIME_FORMAT_USER),
                     'details': self.result
                 }

    def vfcd_explanation(self):
        return [
            self.tariff.cost_info,
            _('Surcharge: $%i') % (self.price,)
        ]

    TICKET_QUERY = 'update ticket set summdopl = summdopl + %i*100, timedopl="%s", status = status | %i where bar="%s"'

    def execute(self, db):
        args = (self.result.price, self.paid_until.strftime(DATETIME_FORMAT), Ticket.PAID, self.ticket.bar)
        ret = db.query(self.TICKET_QUERY % args) is None
        if not ret:
            return ret

        return db.generate_payment(self.db_payment_args)

    def check(self, db):
        args = {
            'base_time': self.base_time.strftime(DATETIME_FORMAT_USER),
            'now': self.now.strftime(DATETIME_FORMAT_USER),
            'cost_info': self.tariff.cost_info_check,
            'duration': self.result.check_duration,
            'paid_until': self.paid_until.strftime(DATETIME_FORMAT_USER),
            'price': self.price,
            'bar': self.ticket.bar
        }

        return (Payment.check(self, db) + _('last payment: %(base_time)s\n'
                                            '   surcharge: %(now)s\n'
                                            '      tariff: %(cost_info)s\n'
                                            'parking duration: %(duration)s\n'
                                            '  paid until: %(paid_until)s\n'
                                            '<hr />\n'
                                            'Price: $%(price)s\n'
                                            '<hr />\n'
                                            '<<%(bar)s>>') % args)


class TicketPaymentUnsupported(Payment):
    def __init__(self, ticket):
        Payment.__init__(self, ticket.payments)
        self.ticket = ticket

    @pyqtProperty(str, constant=True)
    def explanation(self):
        return _('Ticket %s.\n'
                 'Not payable with this tariff.') % (self.ticket.bar,)


class TicketPaymentAlreadyPaid(Payment):
    def __init__(self, ticket):
        Payment.__init__(self, ticket.payments)
        self.ticket = ticket

    @pyqtProperty(str, constant=True)
    def explanation(self):
        conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        conn_cursor = conn.cursor()
        query = "SELECT DTime FROM payment WHERE TalonID == ?"
        conn_cursor.execute(query, [self.ticket.bar])
	result = conn_cursor.fetchall()
	Prnt = result[-1][-1][6:8] + "-" + result[-1][-1][3:5] + "-" + result[-1][-1][0:2] + result[-1][-1][8:14]
	conn.close()
        return _('Ticket %s already paid %s') % (self.ticket.bar,Prnt,)


class TicketPaymentAlreadyOut(Payment):
    def __init__(self, ticket):
        Payment.__init__(self, ticket.payments)
        self.ticket = ticket

    @pyqtProperty(str, constant=True)
    def explanation(self):
        conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        conn_cursor = conn.cursor()
        query = "SELECT DTOut FROM payment WHERE TalonID == ?"
        conn_cursor.execute(query, [self.ticket.bar])
	result = conn_cursor.fetchall()
	Prnt = result[-1][-1][6:8] + "-" + result[-1][-1][3:5] + "-" + result[-1][-1][0:2] + result[-1][-1][8:14]
	conn.close()
        return _('Ticket %s already out %s') % (self.ticket.bar,Prnt,)


class TicketPaymentUndefined(Payment):
    def __init__(self, ticket):
        Payment.__init__(self, ticket.payments)
        self.ticket = ticket

    @pyqtProperty(str, constant=True)
    def explanation(self):
        return _('Ticket %s payment undefined.') % (self.ticket.bar,)


class Ticket(QObject):
    BAR_LENGTH = 18

    IN = 1
    PAID = 5
    OUT = 15

    EXCESS_INTERVAL = 15 * 60  # seconds, TODO: use LocalDB cache to fetch this value instead of constant

    @staticmethod
    def remove(db, bar):
        return db.query('delete from ticket where bar="%s"' % (bar,))

    @staticmethod
    def create(response):
        if response is False:
            return False
        try:
            fields = response[0]
            assert (len(fields) >= 12)
            return Ticket(fields)
        except (TypeError, AssertionError, IndexError, ValueError):
            return None


    BAR_FORMAT = '%m%d%H%M%S%y'
    BAR_PARSE_FORMAT = '%Y%m%d%H%M%S' # оставил для обратной совместимости старых баркодов

    @staticmethod
    def bar_checksum(bar):
        return sum(ord(i) - ord('0') for i in bar[:-2]) & 0xFF

    @staticmethod
    def new_bar(when):
        """
        >>> Ticket.new_bar(datetime(2014, 2, 7, 12, 0, 0))
        '020712000000000012'
        >>> Ticket.new_bar(datetime(2013, 1, 2, 3, 4, 5))
        '010203040500000015'
        """
        my2digits = '00'

        addr = str ([(s.connect(('8.8.8.8', 80)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1])
        #addr = str([ip for ip in socket.gethostbyname_ex(socket.gethostname())[2] if not ip.startswith("127.")][:1])
        p = re.compile('\.\d{1,3}')
        if len(p.findall(addr)[2][1:]) > 2:
            my2digits = p.findall(addr)[2][2:]
        else:
            my2digits = p.findall(addr)[2][1:].rjust(2, '0')

        bar = when.strftime(Ticket.BAR_FORMAT) + my2digits + '0'*4
	line = str(bar)
	cng = [0,0,0,0,0,0,0,0,0,0,0,0]
        codepage = [[2,3,7,8,2,5,7,2,8,7,3,2],[9,6,2,2,4,9,8,9,7,1,6,5],[6,9,6,5,3,5,6,8,8,1,5,2],[5,2,2,2,6,9,5,9,3,4,5,3],[7,7,7,5,7,9,8,5,1,2,4,5],[7,1,5,9,9,5,9,2,4,2,2,2],[7,7,6,1,6,9,6,8,9,2,6,5],[7,4,4,8,8,7,4,7,7,7,4,9],[8,3,9,4,7,3,3,6,1,4,4,3],[1,5,1,7,8,6,3,7,2,7,5,5]]
	code = list(line[0:17])
        for i in range(12):
           	cng[i] = int(code[i]) + codepage[int(str(Ticket.bar_checksum(bar))[-1])][i]
		if cng[i] > 9:
			cng[i] -= 10
	s = [str(k) for k in cng]
	rang = "".join(s)
	barr = str(str(rang) + line[12:16])

        return barr + str(Ticket.bar_checksum(bar)).rjust(2, '0')

    @staticmethod
    def parse_bar(bar):
        """
        This method currently implements heuristics for detecting year of barcode date.
        Since there is no information about year on barcode itself, we try to parse barcode as if it has current year
        and if it fails (no such date) or resulting date is greater than current datetime we try to parse it
        again with previous year.
        @param bar: string, barcode from barcode reader
        @return: datetime.datetime, datetime of ticket moving inside

        NOTE: due to the lack of year information in ticket barcode, there is no way
        to provide a reliable doctest without relying on datetime.now()
        >>> ticket_in = datetime.now()
        >>> ticket_in -= timedelta(days=1, seconds=1800, microseconds=ticket_in.microsecond)
        >>> Ticket.parse_bar(Ticket.new_bar(ticket_in)) == ticket_in
        True
        """

        if len(bar) != Ticket.BAR_LENGTH:
            raise ValueError
        if Ticket.bar_checksum(bar) != int(bar[-2:]):
            raise ValueError

        if bar[10:12] == '00':
            try:
                probable_date = datetime.strptime(str(datetime.now().year) + bar[:10], Ticket.BAR_PARSE_FORMAT)
                if probable_date > datetime.now():
                    raise ValueError
                return probable_date
            except ValueError:
                return datetime.strptime(str(datetime.now().year - 1) + bar[:10], Ticket.BAR_PARSE_FORMAT)
        else:
            return datetime.strptime(bar[:12], Ticket.BAR_FORMAT)

    @staticmethod
    def register(db, bar, telegram=False):
	print ("register by ticket")
        f1 = open ('/mnt/ramdisk/dts11.py', 'r')
        dts11 = f1.read()
        f1.close()
        if dts11 == "1":
            cam.reg_bar_nom(bar)
	barr = coding.decrypt(bar)
        query = 'insert into ticket values("%s", NULL, "%s", NULL, NULL, NULL, NULL, "%s", NULL, NULL, NULL, 1)'
        try:
            ticket_time = Ticket.parse_bar(barr).strftime(DATETIME_FORMAT)
        except ValueError:
            return None
	if telegram == True:
		ticket_time = datetime.now()
		ticket_time = ticket_time.strftime("%y-%m-%d %H:%M:%S")
        args = ("Ticket", bar, ticket_time)
        return db.query(query % args) is None

    def __init__(self, fields):
        QObject.__init__(self)
        self.fields = fields
        self.payments = []

        self.id = fields[1]
        self._bar = fields[2]
        self.tariff_type = int(fields[3]) if fields[3] != 'None' else -1
        self.tariff_price = fields[4]
        self.tariff_sum = fields[5]
        self.tariff_sum_excess = fields[6]
        self.time_in = datetime.strptime(fields[7], DATETIME_FORMAT)
        self.time_out = datetime.strptime(fields[8], DATETIME_FORMAT) if fields[8] != 'None' else None
        self.time_paid = datetime.strptime(fields[9], DATETIME_FORMAT) if fields[9] != 'None' else None
        self.time_excess_paid = datetime.strptime(fields[10], DATETIME_FORMAT) if fields[10] != 'None' else None
        self.status = int(fields[11])

    def __del__(self):
        print '~Ticket'

    @pyqtProperty(str, constant=True)
    def bar(self):
        return self._bar

    @pyqtProperty(int, constant=True)
    def tariff(self):
        return self.tariff_type

    @pyqtSlot(QObject, result=QObject)
    def pay(self, tariff):
        if tariff.type not in [Tariff.FIXED, Tariff.DYNAMIC]:
            return TicketPaymentUnsupported(self)

        if self.status == self.IN:
            return TicketPayment(self, tariff)

        if self.status == self.PAID:
            if self.time_excess_paid:
                if (datetime.now() - self.time_excess_paid).total_seconds() > self.get_interval():
                    return TicketExcessPayment(self, tariff, excess=True)
                else:
                    return TicketPaymentAlreadyPaid(self)

            if self.time_paid:
                if (datetime.now() - self.time_paid).total_seconds() > self.get_interval():
                    return TicketExcessPayment(self, tariff)
                else:
                    return TicketPaymentAlreadyPaid(self)

        if self.status == self.OUT:
            return TicketPaymentAlreadyOut(self)

        return TicketPaymentUndefined(self)

    OUT_QUERY = 'update ticket set timeout="%s", status = status | %i where bar = "%s"'

    def out(self, db):
        return db.query(self.OUT_QUERY % (datetime.now().strftime(DATETIME_FORMAT), self.OUT, self.bar)) is None

    def get_free_time(self):
        try:
            conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	    cursor = conn.cursor()
	    cursor.execute("select FREE_TIME from config_new")
	    results_db = cursor.fetchall()
	    result = results_db [0][0]	
	    conn.close()
            return int(result)
        except (ValueError, KeyError):
            print 'LocalDB_get_free_time_err_log'
            return None


    def get_interval(self):
        try:
            conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	    cursor = conn.cursor()
	    cursor.execute("select INTERVAL from config_new")
	    results_db = cursor.fetchall()
	    result = int(results_db [0][0]) * 60
	    conn.close()
	    print (int(result), "get interval")
            return int(result)
        except (ValueError, KeyError):
            print 'LocalDB_get_free_time_err_log'
            return None

    def Talon(self, free, bar):
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	tariff = int('FREE TIME')
	cursor.execute("UPDATE ticket SET TypeTarif = %i WHERE BAR = %s" % (tariff, bar))
	conn.commit()	
	conn.close()

    def check(self):
	now = datetime.now()
	DTin = self.time_in
	DTCheck = now - DTin
	free = self.get_free_time() * 60
	trans = self.get_free_time()
	bar = self.bar
	#print ((now - self.time_paid).total_seconds(), "total seconds")
        if self.status == self.IN:
	    if DTCheck.total_seconds() > free:
                return False
	    else:
		self.Talon(trans, bar)
		return True

        if self.status == self.PAID:
            now = datetime.now()

            if self.time_paid:
                if (now - self.time_paid).total_seconds() < self.get_interval():
                    return True
                elif self.time_excess_paid and (now - self.time_excess_paid).total_seconds() < self.get_interval():
                    return True

    def to_string_check(self, db):
        return db.get_check_header() + u''.join((
            _('<c><b>P A R K I N G  T I C K E T</b></c>\n\n'),
            #_('Moved inside: %s') % (datetime.now().strftime(DATETIME_FORMAT_USER),),
            _('Moved inside: %s\n<hr />\n') % (datetime.now().strftime(DATETIME_FORMAT_USER),),
            db.get_check_footer(),
            u'<<%s>>' % (self.bar,),
        ))


if __name__ == '__main__':
    import doctest
    doctest.testmod()
