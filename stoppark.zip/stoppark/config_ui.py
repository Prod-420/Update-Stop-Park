# -*- coding: utf-8 -*-
# encoding: utf-8
from PyQt4 import uic
from PyQt4.QtCore import pyqtSignal
from PyQt4.QtGui import QWidget, QDialog
from datetime import datetime
from config import DATETIME_FORMAT_USER
from flickcharm import FlickCharm
from keyboard import Keyboard
from executor import SyncTime
import stoppark
from i18n import language
import sys
from subprocess import Popen

_ = language.ugettext

class Config(QWidget):
    terminals_changed = pyqtSignal()
    terminals_update_requested = pyqtSignal()
    option_changed = pyqtSignal(str, str)
    own_ip_changed = pyqtSignal(str)
    card_create = pyqtSignal(str, str)
    filename = None

    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        self.ui = uic.loadUiType('config.ui')[0]()
        self.ui.setupUi(self)
        self.localize()

        self.terminals = None
        self.payment = None
        self.terminal_config = None

        self.flick = FlickCharm()
        self.flick.activate_on(self.ui.terminalsScrollArea)
        self.flick.activate_on(self.ui.generalScrollArea)

        'self.ui.version.setText(stoppark.__version__)'
        self.get_time()

        #self.ui.updateVersion.setVisible(False)
        self.ui.setupTerminals.clicked.connect(self.setup_terminals)
        self.ui.updateTerminals.clicked.connect(self.begin_terminal_update)

        self.wicd = None
        self.ui.setupNetworkConnection.clicked.connect(self.setup_network_connection)
        self.ui.touchScreen.clicked.connect(self.touch_screen)
        self.ui.unmountFlash.clicked.connect(self.unmount_flash)
        self.ui.saveLogs.clicked.connect(self.save_logs)
        self.ui.updateSystem.clicked.connect(self.update_system)
        self.ui.backupDbButton.clicked.connect(self.backup_database)
        self.ui.addCardButton.clicked.connect(self.add_card)

        self.ui.apbState.stateChanged.connect(lambda state: self.option_changed.emit('apb', str(state)))
        self.ui.rptState.stateChanged.connect(lambda state: self.option_changed.emit('rpt', str(state)))
        self.ui.manualTicketPrint.stateChanged.connect(lambda state: self.option_changed.emit('ticket.manual_print',
                                                                                              str(state)))
        self.ui.viewBarrierButtons.stateChanged.connect(lambda state: self.option_changed.emit('barrier.manual_open',
                                                                                              str(state)))
        self.ui.enableExcessPayment.stateChanged.connect(lambda state: self.option_changed.emit('enableExcess', str(state)))
        self.ui.cbAutoOpenAfterPay.stateChanged.connect(lambda state: self.option_changed.emit('aeap', str(state)))
    def localize(self):
        self.ui.tabs.setTabText(0, _('General'))
        self.ui.tabs.setTabText(1, _('Terminals'))
        self.ui.tabs.setTabText(2, _('Payments'))

        self.ui.versionTitle.setText(_('Version:'))

        self.ui.dateTimeTitle.setText(_('Date and time:'))
        self.ui.setTime.setText(_('Setup'))
        self.ui.getFromSrv.setText(_('Get From Server'))

        self.ui.dbIPTitle.setText(_('DB server IP:'))
        self.ui.setDBIP.setText(_('Setup'))

        #self.ui.networkConnectionTitle.setText(_('Network connection:'))
        self.ui.setupNetworkConnection.setText(_('Setup network connection'))

        self.ui.updateTerminalsTitle.setText(_('Terminal list'))
        self.ui.updateTerminalsHelp.setText(_('Configure and update terminal list:'))
        self.ui.setupTerminals.setText(_('Configure'))
        self.ui.updateTerminals.setText(_('Update'))
        self.ui.testsTitle.setText(_('Tests'))
        self.ui.testDisplayHelp.setText(_('Display test:'))
        self.ui.testDisplay.setText(_('Test display'))
        self.ui.apbTitle.setText(_('Antipassback'))
        self.ui.apbState.setText(_('Enable'))
        self.ui.rptState.setText(_('PPO'))
        self.ui.rptState.setText(_('Enable'))
        self.ui.manualTicketPrintTitle.setText(_('Manual ticket print'))
        self.ui.manualTicketPrint.setText(_('Enable'))
        self.ui.qlAutoExitOnPay.setText(_('AutoExitOnPay'))
        self.ui.cbAutoOpenAfterPay.setText(_('Enable'))
        self.ui.touchScreen.setText(_('TS calibration'))
        self.ui.unmountFlash.setText(_('Eject USB'))
        self.ui.updateSystem.setText(_('Update SW'))
        self.ui.saveLogs.setText(_('Save logs'))
        self.ui.viewTerminalsTitle.setText(_('View terminals title'))
        self.ui.viewBarrierButtons.setText(_('Enable'))
        self.ui.enableExcessPayment.setText(_('Enable'))
        self.ui.enableExcessPaymentTitle.setText(_('Talon excess payment'))
        self.ui.addCardTitle.setText(_('New card entering'))
        self.ui.addCardButton.setText(_('Write to DB'))
        self.ui.backupDbButton.setText(_('DB backup'))
        self.ui.touchScreen.setText(_('TS calibration'))
        self.ui.unmountFlash.setText(_('Eject USB'))
        self.ui.updateSystem.setText(_('Update SW'))
        self.ui.saveLogs.setText(_('Save logs'))


    def begin_session(self, fio, access):
        self.get_time()
        #self.set_time()
        if access in ['admin']:
            [self.ui.tabs.setTabEnabled(i, True) for i in [0, 1, 2]]
            self.ui.setTime.setEnabled(True)
            self.ui.getFromSrv.setEnabled(False)
            self.ui.touchScreen.setEnabled(False)
            self.ui.unmountFlash.setEnabled(True)
            self.ui.updateSystem.setEnabled(True)
            self.ui.saveLogs.setEnabled(True)
            self.ui.backupDbButton.setEnabled(True)
            self.ui.updateTerminals.setEnabled(True)
            self.ui.rptState.setEnabled(False)
            return True
        if access in ['operator']:
            self.ui.tabs.setTabEnabled(0, True)
            self.ui.tabs.setTabEnabled(1, False)
            self.ui.tabs.setTabEnabled(2, False)
            self.ui.setTime.setEnabled(False)
            self.ui.getFromSrv.setEnabled(False)
            self.ui.touchScreen.setEnabled(False)
            self.ui.unmountFlash.setEnabled(False)
            self.ui.updateSystem.setEnabled(False)
            self.ui.saveLogs.setEnabled(False)
            self.ui.backupDbButton.setEnabled(False)
            return True
        if access in ['config']:
            [self.ui.tabs.setTabEnabled(i, True if i == 0 else False) for i in [0, 1, 2]]
            self.ui.setTime.setEnabled(False)
            self.ui.getFromSrv.setEnabled(False)
            self.ui.unmountFlash.setEnabled(True)
            self.ui.touchScreen.setEnabled(False)
            self.ui.saveLogs.setEnabled(True)
            self.ui.backupDbButton.setEnabled(False)
            return True
        return False

    def end_session(self):
        [self.ui.tabs.setTabEnabled(i, False) for i in [0, 1, 2]]
        return True

    def setup(self, terminals, payment):
        self.terminals = terminals
        self.payment = payment

        self.ui.setTime.clicked.connect(self.set_time)
        self.ui.getFromSrv.clicked.connect(self.sync_time)
        self.ui.showKeyboard.clicked.connect(lambda: Keyboard.show())

        self.ui.setDBIP.clicked.connect(self.set_db_ip)
        self.ui.testDisplay.clicked.connect(self.test_display)

    def handle_option(self, key, value):
        handler = {
            'db.ip': lambda v: self.ui.dbIP.setText(v),
            'apb': lambda v: self.ui.apbState.setCheckState(int(v)),
            'rpt': lambda v: self.ui.rptState.setCheckState(int(v)),
            'ticket.manual_print': lambda v: self.ui.manualTicketPrint.setCheckState(int(v)),
            'aeap': lambda v: self.ui.cbAutoOpenAfterPay.setCheckState(int(v)),
            'enableExcess': lambda v: self.ui.enableExcessPayment.setCheckState(int(v)),
            'barrier.manual_open': lambda v: self.ui.viewBarrierButtons.setCheckState(int(v)),
        }.get(str(key), None)
        if handler:
            #print 'found handler for ', key
            handler(value)

    def show_serial_number(self, sn):
        self.ui.cardNumberEdit.setText(sn)


    def sync_time(self):
        from PyQt4.QtCore import QTime, QDate
        st = SyncTime()
        new_date = st.get_time_from_server()
        if new_date is not None:
            self.ui.dateEdit.setDate(QDate(new_date.year, new_date.month, new_date.day))
            self.ui.timeEdit.setTime(QTime(new_date.hour, new_date.minute, new_date.second))

    def get_time(self):
        from PyQt4.QtCore import QTime, QDate

        self.ui.dateEdit.setDate(QDate.currentDate())
        self.ui.timeEdit.setTime(QTime.currentTime())

    def set_time(self):
        from subprocess import Popen

        new_date = self.ui.dateEdit.date()
        new_time = self.ui.timeEdit.time()
        new_datetime = datetime(year=new_date.year(), month=new_date.month(), day=new_date.day(),
                                hour=new_time.hour(), minute=new_time.minute(), second=new_time.second())

        arg = new_datetime.strftime('%m%d%H%M%Y.%S')
        if sys.platform == 'linux2':
            Popen(['date', arg])

    def set_db_ip(self):
        self.option_changed.emit('db.ip', self.ui.dbIP.text())
        self.ui.setDBIPHelp.setText(_('Update: %s') % (datetime.now().strftime(DATETIME_FORMAT_USER)))
        with open("/usr/local/lib/python2.7/dist-packages/stoppark/bash_scripts/server_ip.conf", 'w') as f:
            f.write('HOSTS="%s"' % self.ui.dbIP.text() + '\n')
        cmd = 'xterm -e "sudo -s leafpad /etc/ntp.conf"'
        Popen(cmd, shell=True)

    def test_display(self):
        self.terminals.test_display()
        self.ui.testDisplayResult.setText(_('Update: %s') % (datetime.now().strftime(DATETIME_FORMAT_USER)))

    def add_card(self):
        try:
            card_num = str(self.ui.cardNumberEdit.text())
        except UnicodeEncodeError as e:
            print 'Error ' + str(e)
            card_num = 'ascii'
        card_fam = self.ui.cardFamEdit.text()
        if card_num == '':
            self.card_create.emit('empty', card_fam)
        else:
            self.card_create.emit(card_num, card_fam)

    def setup_terminals(self):
        from terminal_config import TerminalConfig
        self.terminal_config = TerminalConfig()
        if self.terminal_config.exec_() == QDialog.Accepted:
            self.begin_terminal_change()
        self.terminal_config = None

    def terminals_ready(self, ok):
        message = _('successful') if ok else _('unsuccessful')
        now = datetime.now().strftime(DATETIME_FORMAT_USER)
        self.ui.updateTerminalsResult.setText(_('%(message)s (%(now)s)' % {
            'message': message,
            'now': now
        }))
        self.ui.updateTerminals.setEnabled(True)

    def begin_terminal_update(self):
        self.ui.updateTerminals.setEnabled(False)
        self.terminals_update_requested.emit()

    def begin_terminal_change(self):
        self.ui.updateTerminals.setEnabled(False)
        self.terminals_changed.emit()

    def setup_network_connection(self):
        Keyboard.show(layout=[])

        from subprocess import Popen
        if self.wicd is not None:
            if self.wicd.poll() is None:
                return
        self.wicd = Popen(['xterm', '-e', 'sudo', '-s', 'leafpad', '/etc/network/interfaces'])

    def backup_database(self):
        Popen("./downloader_url.py")
        self.ui.backupDbButton.setEnabled(False)

    @staticmethod
    def touch_screen():
        cmd = "/usr/local/lib/python2.7/dist-packages/stoppark/touch_screen"
        Popen(cmd, shell=True)

    @staticmethod
    def unmount_flash():
        cmd = "/home/olimex/unmount_drive.sh"
        Popen(cmd, shell=True)

    @staticmethod
    def save_logs():
        cmd = "/home/olimex/save_logs.sh"
        Popen(cmd, shell=True)

    @staticmethod
    def update_system():
        cmd = "/home/olimex/update_stoppark.sh"
        Popen(cmd, shell=True)
