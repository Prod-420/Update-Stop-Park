
from sqlite3 import connect as sqlite3_connect
from sqlitebck import copy as sqlitebck_copy 

DATABASE_FILENAME = 'data/db.db3'
DATABASE_BACKUP = 'data/backup/db.db3'

def backupDatabase(DATABASE_FILENAME, DATABASE_BACKUP):
    connectDb = sqlite3_connect(DATABASE_FILENAME)
    connectDbBackup = sqlite3_connect(DATABASE_BACKUP)
    sqlitebck_copy(connectDb,connectDbBackup)
    connectDb.close()
    connectDbBackup.close()

backupDatabase(DATABASE_FILENAME, DATABASE_BACKUP)

