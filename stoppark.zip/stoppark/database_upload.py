# -*- coding: utf8 -*-
from string import Template
from database import Connection, Model, DATABASE_FILENAME
from socket import create_connection
from http import access_level, HOST
from datetime import datetime
from shutil import copyfile
import os.path
import sys

DATABASE_FILENAME_BAK = 'data/backup/db.db3'

TEMPLATE = '''
${message}
<form enctype="multipart/form-data" method="POST" action="/upload/" >
 <input type="file" name="file" value="Вибрати файл" /><input id="submit" type="submit" value="Завантажити" />
</form>
'''

TEMPLATE1 = '''
${message}
<form enctype="multipart/form-data" method="POST" action="/download/" >
</form>
'''

class Time(object):
    def __init__(self):
        self.handlers = {
            'GET': {'': self.get},
            'POST': {'': self.post}
        }

    @access_level(2)
    def get(self, request, message=None):
        if not message: message = "good"
        return request.ok([request.content_type['html']], message)

    @access_level(2)
    def post(self, request):
        dt = datetime.now()
        return request.ok([request.content_type['html']], dt.strftime("%d.%m.%Y %H:%M:%S"))

class SetTime(object):
    def __init__(self):
        self.handlers = {
            'GET': {'': self.get},
            'POST': {'': self.post}
        }

    @access_level(2)
    def get(self, request, message=None):
        if not message: message = "good"
        return request.ok([request.content_type['html']], message)

    @access_level(2)
    def post(self, request):
        post = request.post_query()
        try:
            day1 = int(post['d'].value)
            month1 = int(post['m'].value)
            year1 = int(post['y'].value)
            hours = int(post['h'].value)
            mins = int(post['n'].value)
            secs = int(post['s'].value)
            dt = datetime(year1, month1, day1, hours, mins, secs)
            #print dt.strftime("%d.%m.%Y %H:%M:%S")
        except TypeError as e: return request.bad_request(e)
        except KeyError as e: return request.bad_request(e)

        from subprocess import Popen
        arg = dt.strftime('%m%d%H%M%Y.%S')
        arg2 = '-w'
        if sys.platform == 'linux2':
            Popen(['date', arg])
            Popen(['hwclock', arg2])

        create_connection(('127.0.0.1', 101)).send('>>>set_time')
        return request.ok([request.content_type['html']], dt.strftime("%d.%m.%Y %H:%M:%S"))

class DataBaseDownload(object):
    def __init__(self):
        self.handlers = {
            'GET': {'': self.get},
            'POST': {'': self.post}
        }

    DOWNLOAD_MESSAGE = "Завантажити файл бази даних на Ваш комп'ютер"
    FAIL_MESSAGE = 'Не вдалося завантажити файл бази даних'
    SUCCESS_MESSAGE = 'Файл завантажений'

    @access_level(2)
    def get(self, request, message=None):
        if not message: message = self.DOWNLOAD_MESSAGE
        request.start_response(request.OK, [request.content_type['html']])
        return Template(TEMPLATE1).substitute({'message': message})

    @access_level(2)
    def post(self, request):
        try:

            Model.connection.close()

            fld = os.path.split(DATABASE_FILENAME_BAK)[0]

            if not os.path.exists(fld):
                os.mkdir(fld)

            comm = '''
            buffer_size = 1024*1024
            if not hasattr(DATABASE_FILENAME, 'read'):
                source = open(DATABASE_FILENAME, 'rb')
            if not hasattr(DATABASE_FILENAME_BAK, 'write'):
                dest = open(DATABASE_FILENAME_BAK, 'wb')

            while 1:
                copy_buffer = source.read(buffer_size)
                if copy_buffer:
                    dest.write(copy_buffer)
                else:
                    break

            source.close()
            dest.close()
            '''

            copyfile(DATABASE_FILENAME, DATABASE_FILENAME_BAK)

            #with open(DATABASE_FILENAME) as src, \
            #    open(DATABASE_FILENAME_BAK, 'wb') as dst:
            #    dst.write(src.read()), dst.close()

            create_connection(('127.0.0.1', 101)).send('>>>reset')

            #return self.get(request, "<a href='http://"+HOST+"/stoppark/"+DATABASE_FILENAME_BAK+"'>Ссылка для выгрузки базы данных на Ваш компьютер</a>")
            return request.ok([request.content_type['html']], "http://"+HOST+"/stoppark/"+DATABASE_FILENAME_BAK)

        except Exception as e:
            message = '%s: [%s]: %s' % (self.FAIL_MESSAGE, e.__class__.__name__, e)
            return self.get(request, message=message)
        finally:
            Model.connection.open(DATABASE_FILENAME, replace=True)


class DatabaseUploader(object):
    def __init__(self):
        self.handlers = {
            'GET': {'': self.get},
            'POST': {'': self.post}
        }

    INITIAL_MESSAGE = "Виберіть файл бази даних на Вашому комп'ютері і завантажте його на сервер:"
    SUCCESS_MESSAGE = 'Завантаження завершено успішно.'
    FAIL_MESSAGE = 'Не вдалося завантажити файл бази даних'

    @access_level(2)
    def get(self, request, message=None):
        if not message: message = self.INITIAL_MESSAGE
        request.start_response(request.OK, [request.content_type['html']])
        return Template(TEMPLATE).substitute({'message': message})

    @access_level(2)
    def post(self, request):
        try:
            from os import rename, chmod, remove

            new_db = request.post_query()['file']

            if new_db.filename:
                if new_db.filename == 'update.tar.gz':
                    print 'rename: ', new_db.file.name, new_db.filename
                    rename(new_db.file.name, 'data/'+new_db.filename)
                    chmod('data/'+new_db.filename, 0755)
                    create_connection(('127.0.0.1', 101)).send('>>>disconnect')
                    create_connection(('127.0.0.1', 101)).send('>>>reboot')
                    return self.get(request, self.SUCCESS_MESSAGE)

            target_filename = DATABASE_FILENAME + '.new'

            # There is special behaviour in python 2.7 (only ?) FieldStorage class.
            # It doesnt create file using make_file when its size is less than 1000,
            # using StringIO object instead.
            # But since we need file with real filename in FIRMWARE_PATH anyway,
            # we should create this file and dump there contents of current file object.
            # Criteria for this can be either ininstance(firmware.file,NamedTemporaryFile)
            # or hasattr(firmware.file,"name")

            if hasattr(new_db.file, 'name'):
                rename(new_db.file.name, target_filename)
                chmod(target_filename, 0744)
            else:
                open(target_filename, 'wb').write(new_db.file.read())

            Model.connection.open(target_filename, replace=True)
            if Model.connection.test() is None:
                Model.connection.close()
                rename(target_filename, DATABASE_FILENAME)
                # to complete database change process we should reopen db connection in mid.py via special command it can accept
                create_connection(('127.0.0.1', 101)).send('>>>reset')
                return self.get(request, self.SUCCESS_MESSAGE)
            else:
                print "Exception in database file"
                remove(target_filename)
                return self.get(request, self.FAIL_MESSAGE)


            #Model.connection.open(target_filename, replace=True)
            #Model.connection.test()
            #Model.connection.close()

            #rename(target_filename, DATABASE_FILENAME)

            #to complete database change process we should reopen db connection in mid.py via special command it can accept
            create_connection(('127.0.0.1', 101)).send('>>>reset')

            return self.get(request, self.SUCCESS_MESSAGE)
        except Exception as e:
            message = '%s: [%s]: %s' % (self.FAIL_MESSAGE, e.__class__.__name__, e)
            return self.get(request, message=message)
        finally:
            Model.connection.open(DATABASE_FILENAME, replace=True)
