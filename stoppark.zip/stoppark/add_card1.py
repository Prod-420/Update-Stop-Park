# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'add_card.ui'
#
# Created: Mon Jul 27 16:08:47 2020
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import QTime, QDate
import sqlite3
import time
QtWidgets = QtGui
STAFF = 0
ONCE = 1
CLIENT = 2
CASHIER = 3
ADMIN = 4

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Form(object):
    def load(self):
        self.tableWidget.clear()
        self.tableWidget.setRowCount(0)
        labels = ['ID', 'Type', 'CID', _translate("Form", "Прізвище", None), 'DTEnd', _translate("Form", "Номер", None)]

        self.tableWidget.setColumnCount(len(labels))
        self.tableWidget.setHorizontalHeaderLabels(labels)

        with sqlite3.connect('/home/olimex/stoppark/data/db.db3') as connect:
            for ID, Type, CardID, DriveFam, DTEnd, CarGosNom  in connect.execute("SELECT ID, Type, CardID, DriveFam, DTEnd, CarGosNom FROM card"):
                row = self.tableWidget.rowCount()
                self.tableWidget.setRowCount(row + 1)

                self.tableWidget.setItem(row, 0, QtWidgets.QTableWidgetItem(str(ID)))
                self.tableWidget.setItem(row, 1, QtWidgets.QTableWidgetItem(str(Type)))
                self.tableWidget.setItem(row, 2, QtWidgets.QTableWidgetItem(CardID))
                self.tableWidget.setItem(row, 3, QtWidgets.QTableWidgetItem(DriveFam))
                self.tableWidget.setItem(row, 4, QtWidgets.QTableWidgetItem(DTEnd))
                self.tableWidget.setItem(row, 5, QtWidgets.QTableWidgetItem(str(CarGosNom)))


        conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
        conn.close()

    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(660, 368)
        Form.setMinimumSize(QtCore.QSize(660, 368))
        Form.setMaximumSize(QtCore.QSize(660, 368))
        self.tableWidget = QtGui.QTableWidget(Form)
        self.tableWidget.setGeometry(QtCore.QRect(10, 160, 641, 201))
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.gridLayoutWidget = QtGui.QWidget(Form)
        self.gridLayoutWidget.setGeometry(QtCore.QRect(10, 10, 631, 112))
        self.gridLayoutWidget.setObjectName(_fromUtf8("gridLayoutWidget"))
        self.gridLayout = QtGui.QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setMargin(0)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.comboBox = QtGui.QComboBox(self.gridLayoutWidget)
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_translate("Form", "Службова", None))
        self.comboBox.addItem(_translate("Form", "Одноразова", None))
        self.comboBox.addItem(_translate("Form", "Клієнт", None))
        self.comboBox.addItem(_translate("Form", "Касир", None))
        self.comboBox.addItem(_translate("Form", "Адмін", None))
        self.gridLayout.addWidget(self.comboBox, 3, 0, 1, 1)
        self.lineEdit = QtGui.QLineEdit(self.gridLayoutWidget)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.lineEdit.setEnabled(False)
        self.gridLayout.addWidget(self.lineEdit, 1, 0, 1, 1)
        self.label_4 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 0, 2, 1, 1)
        self.label = QtGui.QLabel(self.gridLayoutWidget)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_2 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.label_3 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 0, 1, 1, 1)
        self.lineEdit_3 = QtGui.QLineEdit(self.gridLayoutWidget)
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.gridLayout.addWidget(self.lineEdit_3, 1, 1, 1, 1)
        self.lineEdit_2 = QtGui.QLineEdit(self.gridLayoutWidget)
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.gridLayout.addWidget(self.lineEdit_2, 1, 2, 1, 1)
        self.label_5 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 0, 3, 1, 1)
	data = time.localtime()
        self.dateEdit = QtGui.QDateEdit(self.gridLayoutWidget)
        self.dateEdit.setDateTime(QtCore.QDateTime(QtCore.QDate(data[0], data[1], data[2]), QtCore.QTime(0, 0, 0)))
        self.dateEdit.setTime(QtCore.QTime(0, 0, 0))
        self.dateEdit.setMaximumDateTime(QtCore.QDateTime(QtCore.QDate(7999, 12, 31), QtCore.QTime(23, 59, 59)))
        self.dateEdit.setMaximumDate(QtCore.QDate(7999, 12, 31))
        #self.dateEdit.setDate(QtCore.QDate(2020, 1, 1))
        self.dateEdit.setObjectName(_fromUtf8("dateEdit"))
        self.gridLayout.addWidget(self.dateEdit, 1, 3, 1, 1)
        self.lineEdit_4 = QtGui.QLineEdit(self.gridLayoutWidget)
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.gridLayout.addWidget(self.lineEdit_4, 3, 1, 1, 1)
        self.label_6 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_6.setObjectName(_fromUtf8("label_6"))
        self.gridLayout.addWidget(self.label_6, 2, 1, 1, 1)
        self.label_7 = QtGui.QLabel(self.gridLayoutWidget)
        self.label_7.setObjectName(_fromUtf8("label_7"))
        self.gridLayout.addWidget(self.label_7, 2, 2, 1, 1)
        self.lineEdit_5 = QtGui.QLineEdit(self.gridLayoutWidget)
        self.lineEdit_5.setObjectName(_fromUtf8("lineEdit_5"))
        self.gridLayout.addWidget(self.lineEdit_5, 3, 2, 1, 1)
	self.label_8 = QtGui.QLabel(self.gridLayoutWidget)
	self.label_8.setObjectName(_fromUtf8("label_8"))
	self.gridLayout.addWidget(self.label_8, 2, 3, 2, 1)
	self.label_8.setWordWrap(True)
        self.horizontalLayoutWidget = QtGui.QWidget(Form)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(230, 120, 418, 41))
        self.horizontalLayoutWidget.setObjectName(_fromUtf8("horizontalLayoutWidget"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setMargin(0)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.pushButton_4 = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.horizontalLayout.addWidget(self.pushButton_4)
        self.pushButton_3 = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.horizontalLayout.addWidget(self.pushButton_3)
        self.pushButton_2 = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_4.setEnabled(False)
        self.horizontalLayout.addWidget(self.pushButton_2)
        self.pushButton = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.horizontalLayout.addWidget(self.pushButton)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Card Import v1.1", None))
        self.label_4.setText(_translate("Form", "Прізвище", None))
        self.label.setText(_translate("Form", "Номер картки", None))
        self.label_2.setText(_translate("Form", "Тип картки", None))
        self.label_3.setText(_translate("Form", "CID", None))
        self.label_5.setText(_translate("Form", "Дата закінчення", None))
        self.dateEdit.setDisplayFormat(_translate("Form", "dd.MM.yyyy", None))
        self.label_6.setText(_translate("Form", "Десятковий", None))
        self.label_7.setText(_translate("Form", "Номер авто", None))
	self.label_8.setText(_translate("Form", "", None))
        self.pushButton_4.setText(_translate("Form", "Змінити", None))
        self.pushButton_3.setText(_translate("Form", "Видалити", None))
        self.pushButton_2.setText(_translate("Form", "Зчитати CID", None))
        self.pushButton.setText(_translate("Form", "Добавить", None))

