# -*- coding: utf-8 -*-
from PyQt4 import uic
from PyQt4.QtGui import QWidget, QApplication, QIcon, QSystemTrayIcon, QDialog
from executor import Executor
from login import LoginDialog, LogoffDialog
from db import LocalDB
from card import Card
from ticket import Ticket
from datetime import datetime
from i18n import language
from config import DATE_FORMAT1
from datetime import date
from time import sleep
_ = language.ugettext


class Main(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)

        # Write changes to local db
        self.db = LocalDB(initialize=False)
        self.serverIP = self.db.option('db.ip')
        self.db.close_connection()
        sleep(1)
        self.ui = uic.loadUiType('main.ui')[0]()
        self.ui.setupUi(self)
        self.localize()

        self.ui.config.setup(self.ui.terminals, self.ui.payments)
        self.tabs = [self.ui.terminals, self.ui.payments, self.ui.config, self.ui.rpt]

        self.ui.terminals.ready.connect(self.ui.config.terminals_ready)

        self.left_terminals = []
        self.right_terminals = []

        self.ui.leftUp.clicked.connect(self.left_up)
        self.ui.leftDown.clicked.connect(self.left_down)
        self.ui.rightUp.clicked.connect(self.right_up)
        self.ui.rightDown.clicked.connect(self.right_down)
        self.ui.printTicket.clicked.connect(self.print_ticket)

        self.end_session()

        self.notifier = QSystemTrayIcon(QIcon('up.svg'), self)
        self.notifier.show()

        self.session = None
        self.executor = self.setup_executor()
        self.executor.start()
        sleep(2)  # timeout for executor init to solve a problem, when gui is not started.
        self.executor.notify_terminals()  # Загружаем список терминалов при старте приложения вне зависимости от сессии

    def localize(self):
        self.setWindowTitle('Stop-Park (licensed)')
        self.ui.tabs.setTabText(0, _('Terminals'))
        self.ui.tabs.setTabText(1, _('Payments'))
        self.ui.tabs.setTabText(2, _('Config'))
        self.ui.tabs.setTabText(3, _('PPO'))

    def setup_payments(self, executor):
        self.ui.payments.tariff_update_requested.connect(executor.update_tariffs)
        executor.tariffs_updated.connect(self.ui.payments.update_tariffs)

        executor.new_payable.connect(self.ui.payments.handle_payable)
        self.ui.payments.payable_accepted.connect(lambda: self.ui.tabs.setCurrentIndex(1))

        self.ui.payments.display_requested.connect(executor.display)
        self.ui.payments.manual_ticket_inputted.connect(executor.handle_bar)
        self.ui.payments.notify_requested.connect(self.notifier.showMessage)

        self.ui.payments.payment_initiated.connect(executor.pay)
        executor.payment_processed.connect(self.ui.payments.handle_payment_processed)
        executor.payment_error.connect(self.ui.payments.handle_payment_error)
        executor.open_terminal_after_pay.connect(self.find_first_out)

    def setup_executor(self):
        executor = Executor()

        executor.notify.connect(lambda title, msg: self.notifier.showMessage(title, msg))

        self.setup_payments(executor)

        executor.new_operator.connect(self.handle_operator)
        executor.session_begin.connect(self.begin_session)
        executor.session_end.connect(self.end_session)

        executor.option_notification.connect(self.handle_option)
        self.ui.config.option_changed.connect(executor.set_option)

        # self.ui.config.terminals_changed.connect(executor.notify_terminals)
        self.ui.config.terminals_update_requested.connect(executor.update_terminals_list)
        executor.terminals_notification.connect(self.update_terminals)

        # self.ui.rpt.send_cmd_to_fiscal_printer.connect(executor.fiscal_printer_handler)
        # executor.result_fiscal_operation.connect(self.ui.rpt.processed)

        executor.new_card.connect(self.ui.config.show_serial_number)
        self.ui.config.card_create.connect(executor.insert_card)

        return executor

    def find_first_out(self):
        self.ui.terminals.terminal_auto_open(1)
        # for addr in self.left_terminals:
        #    if 1 == addr % 2:  # direction is 0 for moving in and 1 for moving out
        #        print 'left: ', addr
        #        self.ui.terminals.terminal_auto_open(addr)
        #        return
        # for addr in self.right_terminals:
        #    if 1 == addr % 2:
        #        print 'right: ', addr
        #        self.ui.terminals.terminal_auto_open(addr)
        #        return
    #    self.queue.put(lambda terminal: TerminalState('auto', 'out_open').set(terminal, addr, self.db))

    @staticmethod
    def disconnect_from_signal(signal, slot):
        try:
            signal.disconnect(slot)
            return True
        except TypeError:  # .disconnect raises TypeError when given signal is not connected
            return False

    def handle_operator(self, card):
        print 'operator or admin', card

        if date.today() > card.date_end:
            self.notifier.showMessage(_('Card %(sn)s  %(fio)s') % {'sn': card.sn, 'fio': card.fio},
                                      _('Is expired %(end)s') % {'end': card.date_end.strftime(DATE_FORMAT1)})
            return

        if not self.disconnect_from_signal(self.executor.new_operator, self.handle_operator):
            return

        if self.session is None:
            """
            if self.executor.get_fiscal_printer_state():
                #if self.executor.fiscal_printer.get_time(): DAlex 24.10.2014 Have to get time from server
                if card.type == Card.CASHIER:
                    if self.executor.cashier_registration(card):
                        self.login(card)

                if card.type == Card.ADMIN:
                    self.login(card)
            else:
                self.login(card)"""
            self.login(card)

        elif self.session == card.sn or card.type == Card.ADMIN:
                login_dialog = LogoffDialog(card, self.executor)
                if login_dialog.exec_() == QDialog.Accepted:
                    self.executor.end_session()

        self.executor.new_operator.connect(self.handle_operator)

    def login(self, card):
        login_dialog = LoginDialog(card, parent=self)
        if login_dialog.exec_() == QDialog.Accepted:
            self.executor.begin_session(card)

    def begin_session(self, sn, fio, access):
        self.session = sn
        if sn == 'system':
            self.ui.terminals.begin_session(fio, access)
        else:
            for tab_index, tab_widget in enumerate(self.tabs):
                self.ui.tabs.setTabEnabled(tab_index, tab_widget.begin_session(fio, access))

        if access in ['admin', 'operator']:
            print 'begin_session_admin_operator'
            self.ui.tabs.setTabEnabled(3, False)
        else:
            self.update_buttons()

        if sn == 'system':
            self.end_session()

    def end_session(self):
        self.session = None
        for tab_index, tab_widget in enumerate(self.tabs):
            if tab_widget.end_session():
                self.ui.tabs.setTabEnabled(tab_index, False)
            else:
                self.ui.tabs.setCurrentIndex(tab_index)

    def handle_option(self, key, value):
        if key == 'barrier.manual_open': 
            if value == '0':
                self.ui.tabs.setTabEnabled(0, False)
        if key == 'ticket.manual_print':
            self.ui.printTicket.setEnabled(value == '2')
        self.ui.config.handle_option(key, value)

    def update_terminals(self, terminals=None):
        if terminals is None:
            terminals = {}
        else:
            self.ui.terminals.reset_mainloop(terminals)

        self.left_terminals = [key for key, value in terminals.iteritems() if value.option == 'left']
        self.ui.leftUp.setEnabled(not not self.left_terminals)
        self.ui.leftDown.setEnabled(not not self.left_terminals)

        self.right_terminals = [key for key, value in terminals.iteritems() if value.option == 'right']
        self.ui.rightUp.setEnabled(not not self.right_terminals)
        self.ui.rightDown.setEnabled(not not self.right_terminals)

    def left_up(self):
        for addr in self.left_terminals:
            self.ui.terminals.terminal_open(addr)

    def left_down(self):
        for addr in self.left_terminals:
            self.ui.terminals.terminal_close(addr)

    def right_up(self):
        for addr in self.right_terminals:
            self.ui.terminals.terminal_open(addr)

    def right_down(self):
        for addr in self.right_terminals:
            self.ui.terminals.terminal_close(addr)

    def print_ticket(self):
        self.executor.handle_bar(Ticket.new_bar(datetime.now()), emit=False, to_printer=True)

    def closeEvent(self, event):
        self.ui.terminals.close_session(block=True)
        self.executor.stop()

        return QWidget.closeEvent(self, event)

if __name__ == '__main__':
    import sys
    # import config
    # config.setup_logging('u2')
    # config.setup_logging()

    app = QApplication(sys.argv)

    widget = Main()
    widget.showMaximized()

    sys.exit(app.exec_())
