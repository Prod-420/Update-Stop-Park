#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from PyQt4 import uic
from PyQt4.QtGui import QApplication, QMainWindow, QFileDialog
from PyQt4.QtCore import pyqtSignal
from time import sleep
from db import LocalDB          # class in Client folder stoppark
from gevent import socket
import requests
from threading import Thread
from i18n import language       # localization class in Client folder stoppark
from filesize import Humanize   # class in Client folder stoppark
from os import remove
import datetime

_ = language.ugettext


class FileMenu(QFileDialog):
    """Open system gui file save menu """
    fileName = 'backup.zip'
    filePath = "/media/hdd/"

    def file_timestamp(self):
        """ Add ISO timestamp to backup file name """
        d = datetime.datetime.now()
        file_name = d.strftime("%Y-%m-%d_%H%M_") + self.fileName
        return self.filePath + file_name

    def menu_file_path(self):
        """Return file path string """
        time_stamp = self.file_timestamp()
        return self.getSaveFileName(self, "Save file", time_stamp, filter="zip (*.zip *.)")


class Downloader(QMainWindow):
    """ Create the backup for SQLite database on stoppark server and save it in chosen folder. """
    progressChanged = pyqtSignal(int)   # update download progress bar
    readUpdate = pyqtSignal(str)        # update text in log gui
    saveButtonState = pyqtSignal(bool)  # signals for update buttons from threads
    makeButtonState = pyqtSignal(bool)
    pathButtonState = pyqtSignal(bool)

    def __init__(self):
        super(Downloader, self).__init__()
        self.cancelEvent = False  # stop all threads variable
        self.ui = uic.loadUi('downloader_url.ui', self)
        self.localize()
        self.db = LocalDB(initialize=False)
        self.serverIP = self.db.option('db.ip')
        self.db.close_connection()
        # read server ip from local sqlite database ~/.stoppark/db
        self.basePath = "/stoppark/data/backup.zip"
        # path for database backup on server
        self.file_menu = FileMenu()
        self.show_file_path(self.file_menu.file_timestamp())
        self.setPathButton.clicked.connect(self.save_file_path)
        self.saveFileButton.clicked.connect(self.write_file)
        self.makeBackupButton.clicked.connect(self.backup_base)
        self.cancelButton.clicked.connect(self.cancel_set)
        self.progressChanged.connect(self.progressBar.setValue)
        self.readUpdate.connect(self.ui.infoView.append)
        self.closeButton.clicked.connect(self.close_event)
        self.saveButtonState.connect(self.ui.saveFileButton.setEnabled)
        self.makeButtonState.connect(self.ui.makeBackupButton.setEnabled)
        self.pathButtonState.connect(self.ui.setPathButton.setEnabled)
        self.show()

    def localize(self):
        self.ui.pathTitle.setText(_('Downloader path'))
        self.ui.setPathButton.setText(_('Downloader set path'))
        self.ui.makeBackupButton.setText(_('Downloader make backup'))
        self.ui.saveFileButton.setText(_('Downloader save file'))
        self.ui.cancelButton.setText(_('Cancel'))
        self.ui.Logs_label.setText(_('Downloader logs'))
        self.ui.closeButton.setText(_('Downloader close application'))

    def close_event(self):
        """ close application """
        self.cancelEvent = True  # cancel all threads
        sleep(3)
        sys.exit(0)

    def cancel_set(self):
        """ set stop all threads variable """
        self.cancelEvent = True

    def cancel_clean(self):
        """ unset stop all threads variable"""
        self.cancelEvent = False

    def show_file_path(self, file_path):
        """ update file path PlainText in gui """
        self.ui.filePath.setPlainText(file_path)

    def backup_command(self, file_url):
        """ Send backup command to server (port 101),
        verify answer and print file size, last modified date
        """
        self.cancel_clean()
        self.readUpdate.emit('Get From Server: ' + self.serverIP)
        peer = self.serverIP, 101
        answer = ''
        try:
            backup_socket = socket.create_connection(peer, timeout=5)
            backup_socket.send('>>>backup_base:')
            answer = backup_socket.recv(512)
        except socket.timeout:
            self.readUpdate.emit('Error timeout, server not respond')
        except socket.error, e:
            self.readUpdate.emit(str(e))  # Other errors
        self.readUpdate.emit(answer)
        if answer[:20] == 'Start backup process':
            self.saveButtonState.emit(False)
            self.makeButtonState.emit(False)
            sleep(3)
            humanize = Humanize()         # for converting file size in human readable format
            timeout_counter = 0
            backup_counter = 0
            while not self.cancelEvent:
                try:
                    backup_socket = socket.create_connection(peer, timeout=5)
                    backup_socket.send('>>>backup_status')
                    answer = backup_socket.recv(512)
                    if answer[:14] == 'Backup created':
                        self.readUpdate.emit(answer)
                        self.saveButtonState.emit(True)
                        try:
                            response = requests.get(file_url, stream=True)
                            response.raise_for_status()  # for error HTTP 404, 403
                            file_modified = response.headers['last-modified']
                            self.readUpdate.emit(file_modified)
                            file_size = int(response.headers['Content-Length'])
                            self.readUpdate.emit(humanize.natural_size(file_size))
                            self.readUpdate.emit(answer)
                            self.saveButtonState.emit(True)
                            break
                        except requests.exceptions.RequestException as e:
                            self.readUpdate.emit(str(e))
                            self.makeButtonState.emit(True)
                            self.saveButtonState.emit(True)
                            break
                except socket.timeout, e:
                    err = e.args[0]
                    if err == 'timed out':
                        timeout_counter += 1
                        self.readUpdate.emit('timeout: ' + str(timeout_counter*6) + ' s')
                        sleep(1)
                        if timeout_counter < 200:
                            continue
                        else:
                            self.readUpdate.emit('Error server timeout')
                            break
                    else:
                        self.readUpdate.emit(str(e))
                        break
                except socket.error, e:
                    self.readUpdate.emit(str(e))  # Other errors
                    break
                else:
                    sleep(5)
                    backup_counter += 1
                    if len(answer) == 0:
                        self.readUpdate.emit('Error server answer is empty')
                        break
                    else:
                        self.readUpdate.emit(answer + ': ' + str(backup_counter*5) + ' s')
            if answer[:14] != 'Backup created':
                self.readUpdate.emit(answer)
                self.readUpdate.emit('Backup not created.')
                self.makeButtonState.emit(True)
                self.saveButtonState.emit(True)
        else:
            self.readUpdate.emit('Backup not created: ' + answer)
            self.makeButtonState.emit(True)
            self.saveButtonState.emit(True)

    def backup_base(self):
        """ Start thread for backup database on server """
        file_url = "http://" + self.serverIP + self.basePath
        Thread(name='backup_loop', target=self.backup_command, args=(file_url,)).start()

    def read_loop(self, target_path, file_url):
        """ Download database backup from server and save to a local drive. """
        self.saveButtonState.emit(False)
        self.pathButtonState.emit(False)
        self.cancel_clean()
        try:
            response = requests.get(file_url, stream=True)
            response.raise_for_status()
            self.makeButtonState.emit(False)
            try:
                handle = open(target_path, "wb")
                var_bars = 0
                block_size = 512
                for chunk in response.iter_content(chunk_size=block_size):
                    if chunk and not self.cancelEvent:  # filter out keep-alive new chunks
                        handle.write(chunk)
                        var_bars += 1
                        self.progressChanged.emit(var_bars)
                    else:
                        self.progressChanged.emit(0)
                        try:
                            remove(target_path)
                        except:
                            self.readUpdate.emit("Error delete file filed")
                        break
                if self.cancelEvent:
                    self.readUpdate.emit("Download failed, cancelled.")
                    self.cancel_clean()
                else:
                    self.readUpdate.emit("Download complete")
                handle.close()
            except IOError as e:
                self.readUpdate.emit("Path I/O error ({0}): {1}".format(e.errno, e.strerror))
            # except:  # handle other exceptions such as attribute errors
            #    self.readUpdate.emit("Unexpected error:", sys.exc_info()[0])
            self.saveButtonState.emit(True)
            self.makeButtonState.emit(True)
            self.pathButtonState.emit(True)
        except requests.exceptions.RequestException as e:
            self.readUpdate.emit(str(e))

    def write_file(self):
        """ Start thread for writing backup to the local drive. """
        file_url = "http://" + self.serverIP + self.basePath
        target_path = self.ui.filePath.toPlainText()
        try:
            response = requests.get(file_url, stream=True)
            response.raise_for_status()
            file_size = int(response.headers['Content-Length'])
            max_bar = file_size / 512                      # progress bar max value
            self.progressBar.setRange(0, max_bar)
            Thread(name='read_loop', target=self.read_loop, args=(target_path, file_url,)).start()
        except requests.exceptions.RequestException as e:  # This is the correct syntax
            self.ui.infoView.append(str(e))

    def save_file_path(self):
        """ File path for backup on the local drive. """
        target_path = self.file_menu.menu_file_path()
        self.show_file_path(target_path)
        self.progressBar.setValue(0)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = Downloader()
    app.exec_()
