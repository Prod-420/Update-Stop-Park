# -*- coding: utf-8 -*-

from PyQt4 import QtCore, QtGui
import sys
import Change_master 
from serial_port import SerialPort
from gevent import spawn, sleep, get_hub, socket
import sqlite3
import os
import mifare_coding

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

def Change(cache):
	try:
		path = os.path.join(os.path.abspath(os.path.dirname(__file__)),"/usr/local/lib/python2.7/dist-packages/stoppark/Time.py")
		os.remove(path)
	except Exception:
		head = "cache = "
		data = head + '"' + cache + '"'
		f1 = open("/usr/local/lib/python2.7/dist-packages/stoppark/Time.py", 'w')
		f1.write(data)
		f1.close()
		Form.ui.label.setText(_translate("Form", "Майстер ключ змінено", None))
	else:
		head = "cache = "
		data = head + '"' + cache + '"'
		f1 = open("/usr/local/lib/python2.7/dist-packages/stoppark/Time.py", 'w')
		f1.write(data)
		f1.close()
		Form.ui.label.setText(_translate("Form", "Майстер ключ змінено", None))
def resv():
	buff = ''
        while (buff == ''):
	    sock.send('n')
            sleep(0.1)
            buff += sock.recv(30)
	    if buff == "1":
		buff = ''
	    if (len(buff)) == 16:
                    if buff[1] == '0' and buff[2] == '0':
                        after = mifare_coding.main(buff[7:-1])
                        buff = ";00" + after + "?"
                    else:
                        after = mifare_coding.main(buff[1:-1])
                        buff = ";00" + after + "?"
        st = buff.index(';') + 1
	end = buff.index('?',st)
	conn = sqlite3.connect('/home/olimex/stoppark/data/db.db3')
	cursor = conn.cursor()
	data_ck = buff[st:end]
	print (data_ck)
	sql = "SELECT ID FROM card WHERE CardID=?"
	cursor.execute(sql, [buff[st:end]])
	results_ck = cursor.fetchall()
	try:
		print(results_ck[0][0])
	except LookupError:
		Change(buff[st:end])
	else:
		Form.ui.label.setText(_translate("Form", "Використайте іншу картку", None))
	conn.close()

class Change_card_gui(QtGui.QWidget):
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)
		self.ui = Change_master.Ui_Form()
		self.ui.setupUi(self)

if __name__ == "__main__":
	app = QtGui.QApplication(sys.argv)
	Form = Change_card_gui()
	Form.show()
	sock = SerialPort('/dev/ttyS4', 9600)
	Form.ui.pushButton.clicked.connect(resv)
	sys.exit(app.exec_())
